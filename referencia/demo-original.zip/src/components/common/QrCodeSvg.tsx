import React from 'react';

interface QrCodeSvgProps {
  value: string;
  size?: number;
  className?: string;
  bgColor?: string;
  fgColor?: string;
}

export const QrCodeSvg: React.FC<QrCodeSvgProps> = ({
  value,
  size = 200,
  className = '',
  bgColor = '#FFFFFF',
  fgColor = '#0F172A',
}) => {
  // Generate a deterministic aesthetic QR grid based on the value string
  const gridSize = 25;
  const hashVal = value.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  // Helper to determine if a cell is in one of the 3 corner finder patterns
  const isFinderPattern = (r: number, c: number) => {
    // Top-left
    if (r < 7 && c < 7) return true;
    // Top-right
    if (r < 7 && c >= gridSize - 7) return true;
    // Bottom-left
    if (r >= gridSize - 7 && c < 7) return true;
    return false;
  };

  const isFinderPixelFilled = (r: number, c: number) => {
    // Normalize to 0-6
    let nr = r;
    let nc = c;
    if (r < 7 && c >= gridSize - 7) {
      nc = c - (gridSize - 7);
    } else if (r >= gridSize - 7 && c < 7) {
      nr = r - (gridSize - 7);
    }
    // Outer border
    if (nr === 0 || nr === 6 || nc === 0 || nc === 6) return true;
    // Inner center square (2 to 4)
    if (nr >= 2 && nr <= 4 && nc >= 2 && nc <= 4) return true;
    return false;
  };

  // Build matrix
  const matrix: boolean[][] = [];
  for (let r = 0; r < gridSize; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < gridSize; c++) {
      if (isFinderPattern(r, c)) {
        row.push(isFinderPixelFilled(r, c));
      } else if (r === 6 || c === 6) {
        // Timing patterns
        row.push((r + c) % 2 === 0);
      } else {
        // Pseudo-random data bits influenced by value hash and position
        const seed = (r * 31 + c * 17 + hashVal) % 97;
        row.push(seed % 2 === 0 || (r * c + seed) % 3 === 0);
      }
    }
    matrix.push(row);
  }

  const cellSize = 100 / gridSize;

  return (
    <div
      className={`relative inline-flex items-center justify-center p-3 rounded-2xl shadow-sm border border-slate-200 bg-white ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
        shapeRendering="crispEdges"
      >
        <rect width="100" height="100" fill={bgColor} rx="6" />
        {matrix.map((row, r) =>
          row.map((filled, c) => {
            if (!filled) return null;
            return (
              <rect
                key={`${r}-${c}`}
                x={c * cellSize}
                y={r * cellSize}
                width={cellSize * 1.02}
                height={cellSize * 1.02}
                fill={fgColor}
              />
            );
          })
        )}
      </svg>

      {/* Decorative center logo badge */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-lg border-2 border-white font-bold text-xs">
          AI
        </div>
      </div>
    </div>
  );
};
