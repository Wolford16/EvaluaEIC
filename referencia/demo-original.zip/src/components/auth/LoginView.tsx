import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Eye,
  EyeOff,
  ArrowRight,
  QrCode,
  ShieldCheck,
  GraduationCap,
  Lock,
  User,
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, startParticipantFlow } = useApp();

  const [username, setUsername] = useState('docente');
  const [password, setPassword] = useState('123456');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const u = username.trim().toLowerCase();
    if (u === 'admin' && password === '123456') {
      login('admin');
    } else if ((u === 'docente' || u === 'supervisor') && password === '123456') {
      login('docente');
    } else {
      setErrorMsg('Usuario o contraseña incorrectos. Utiliza los accesos de prueba.');
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-slate-900 text-slate-100 p-4 selection:bg-blue-600 selection:text-white">
      <div className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Brand header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white mx-auto shadow-lg shadow-blue-500/25">
            <Sparkles className="w-6 h-6" />
          </div>
          <h1 className="font-heading font-black text-2xl text-white tracking-tight">
            Evalua<span className="text-blue-500">IA</span>
          </h1>
          <p className="text-xs text-slate-400">
            Plataforma simple de evaluaciones con IA y salas QR
          </p>
        </div>

        {/* Quick Roles Buttons */}
        <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
          <span className="text-[10px] uppercase font-bold text-slate-400 block text-center">
            Acceso Rápido con 1 Clic
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => login('docente')}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-emerald-400" />
                <span>Docente</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">docente / 123456</div>
            </button>

            <button
              type="button"
              onClick={() => login('admin')}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                <span>Administrador</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">admin / 123456</div>
            </button>
          </div>
        </div>

        {/* Manual Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
              {errorMsg}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Usuario
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="docente o admin"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs pl-9 focus:outline-none focus:border-blue-500"
                required
              />
              <User className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Contraseña
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="123456"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs pl-9 pr-9 focus:outline-none focus:border-blue-500"
                required
              />
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5"
          >
            <span>Iniciar Sesión</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Big direct button for Participants (no login needed!) */}
        <div className="pt-4 border-t border-slate-800">
          <button
            type="button"
            onClick={() => startParticipantFlow()}
            className="w-full py-3 px-4 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 transition"
          >
            <QrCode className="w-4 h-4 text-amber-400" />
            <span>Entrar como Participante / Alumno (QR)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
