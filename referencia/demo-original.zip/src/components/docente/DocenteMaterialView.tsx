import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { QrCodeSvg } from '../common/QrCodeSvg';
import {
  FileText,
  UploadCloud,
  CheckCircle2,
  Trash2,
  QrCode,
  Users,
  Trophy,
  Play,
  Clock,
  Plus,
  BookOpen,
  ArrowRight,
  Sparkles,
  ExternalLink,
  ChevronLeft,
  X,
  Layers,
} from 'lucide-react';

interface DocenteMaterialViewProps {
  onOpenUpload: () => void;
}

export const DocenteMaterialView: React.FC<DocenteMaterialViewProps> = ({ onOpenUpload }) => {
  const {
    documents,
    selectedDocId,
    setSelectedDocId,
    deleteDocument,
    removeQuestionFromDocument,
    createRoomForDocument,
    rooms,
    startRoomActivity,
    startParticipantFlow,
    showToast,
  } = useApp();

  // Active tab inside the selected document
  const [docTab, setDocTab] = useState<'preguntas' | 'participantes' | 'ranking'>('preguntas');

  // QR Launcher Modal State
  const [showQrModal, setShowQrModal] = useState(false);
  const [timeSeconds, setTimeSeconds] = useState(20);

  const activeDoc = selectedDocId ? documents.find((d) => d.id === selectedDocId) || null : null;
  const activeRoom = activeDoc ? rooms.find((r) => r.documentId === activeDoc.id) : null;
  const participantsList = activeRoom ? activeRoom.participants : [];
  const sortedParticipants = [...participantsList].sort((a, b) => b.score - a.score);

  if (documents.length === 0) {
    return (
      <div className="p-10 sm:p-14 text-center bg-white rounded-3xl border border-slate-200 shadow-sm space-y-4 max-w-lg mx-auto my-8 animate-in fade-in">
        <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto shadow-inner">
          <UploadCloud className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900 font-heading">
            No tienes documentos cargados aún
          </h2>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
            Sube un archivo PDF para que la Inteligencia Artificial analice el contenido y formule las preguntas de tu examen automáticamente.
          </p>
        </div>
        <button
          onClick={onOpenUpload}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-xs font-bold shadow-md transition inline-flex items-center gap-2"
        >
          <UploadCloud className="w-4 h-4" />
          <span>Cargar mi primer documento PDF</span>
        </button>
      </div>
    );
  }

  // Handle open QR launch modal
  const handleOpenLaunchModal = () => {
    if (!activeDoc) return;
    createRoomForDocument(activeDoc.id, timeSeconds);
    setShowQrModal(true);
  };

  const handleStartExamNow = () => {
    if (activeRoom) {
      startRoomActivity(activeRoom.id);
    }
  };

  const handleCardClick = (docId: string) => {
    // If clicking the already open PDF, close it so only cards remain!
    if (selectedDocId === docId) {
      setSelectedDocId(null);
    } else {
      // If clicking a closed card, open its questions
      setSelectedDocId(docId);
      setDocTab('preguntas');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header: Simple and Clean */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 font-heading flex items-center gap-2.5">
            <Layers className="w-6 h-6 text-blue-600" />
            <span>Mis Documentos y Material de Cátedra</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Haz clic sobre una tarjeta para abrir sus preguntas y ranking. Vuelve a hacer clic para cerrarla.
          </p>
        </div>

        <button
          onClick={onOpenUpload}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-2xl shadow-md transition self-start sm:self-auto"
        >
          <UploadCloud className="w-4 h-4" />
          <span>Cargar Nuevo PDF</span>
        </button>
      </div>

      {/* PDF Identification Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {documents.map((doc) => {
          const isOpen = activeDoc?.id === doc.id;
          return (
            <div
              key={doc.id}
              onClick={() => handleCardClick(doc.id)}
              className={`p-5 rounded-3xl border transition-all cursor-pointer relative overflow-hidden group select-none ${
                isOpen
                  ? 'bg-blue-50/50 border-blue-500 ring-2 ring-blue-500/20 shadow-md'
                  : 'bg-white border-slate-200 hover:border-blue-300 hover:shadow-md'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold transition ${
                    isOpen ? 'bg-blue-600 text-white shadow-md' : 'bg-rose-50 text-rose-600 group-hover:bg-blue-50 group-hover:text-blue-600'
                  }`}
                >
                  <FileText className="w-5 h-5" />
                </div>

                <div className="flex items-center gap-1.5">
                  <span
                    className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full border transition ${
                      isOpen
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-100 text-slate-600 border-slate-200 group-hover:bg-blue-50 group-hover:text-blue-600 group-hover:border-blue-200'
                    }`}
                  >
                    {isOpen ? 'Abierto' : `${doc.questions.length} preguntas`}
                  </span>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`¿Eliminar documento "${doc.title}"?`)) {
                        deleteDocument(doc.id);
                        if (selectedDocId === doc.id) setSelectedDocId(null);
                      }
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                    title="Eliminar PDF"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h3 className="font-bold text-sm text-slate-900 group-hover:text-blue-600 transition leading-snug line-clamp-2">
                {doc.title}
              </h3>
              <p className="text-[11px] text-slate-400 mt-1 font-mono truncate">
                {doc.fileName}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5 text-slate-400" />
                  {doc.pages} páginas
                </span>
                <span className="font-medium text-blue-600 group-hover:underline flex items-center gap-1">
                  {isOpen ? (
                    <>
                      <X className="w-3.5 h-3.5" />
                      <span>Cerrar</span>
                    </>
                  ) : (
                    <>
                      <span>Abrir preguntas</span>
                      <span>→</span>
                    </>
                  )}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Document Details: Only shown if activeDoc is not null */}
      {activeDoc && (
        <div className="bg-white rounded-3xl border border-blue-200 ring-2 ring-blue-500/10 shadow-lg overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
          {/* Document Header Banner */}
          <div className="p-6 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-widest px-2 py-0.5 rounded-md bg-blue-600 text-white">
                  Documento Abierto
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedDocId(null)}
                  className="text-[11px] font-bold text-slate-500 hover:text-slate-800 hover:underline flex items-center gap-1"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Cerrar para ver solo las tarjetas</span>
                </button>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-heading mt-1.5">
                {activeDoc.title}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                {activeDoc.fileName} • Subido por: <strong className="text-slate-700">{activeDoc.uploadedBy}</strong> el {activeDoc.uploadDate}
              </p>
            </div>

            {/* Launch QR Button */}
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                type="button"
                onClick={handleOpenLaunchModal}
                className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold text-xs shadow-lg shadow-blue-500/20 transition"
              >
                <QrCode className="w-4 h-4" />
                <span>Lanzar Sala QR / Examen</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedDocId(null)}
                className="p-3 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-2xl transition"
                title="Cerrar vista de preguntas"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

        {/* 3 Main Apartados Tabs: Preguntas | Participantes | Ranking */}
        <div className="flex border-b border-slate-200 px-6 bg-white">
          <button
            onClick={() => setDocTab('preguntas')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition ${
              docTab === 'preguntas'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>1. Preguntas ({activeDoc.questions.length})</span>
          </button>

          <button
            onClick={() => setDocTab('participantes')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition ${
              docTab === 'participantes'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>2. Participantes ({participantsList.length})</span>
          </button>

          <button
            onClick={() => setDocTab('ranking')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition ${
              docTab === 'ranking'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Trophy className="w-4 h-4 text-amber-500" />
            <span>3. Ranking y Resultados</span>
          </button>
        </div>

        {/* Tab 1 Content: PREGUNTAS */}
        {docTab === 'preguntas' && (
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between pb-2">
              <p className="text-xs text-slate-500">
                Preguntas generadas por la IA para este documento. Puedes eliminar las que no consideres convenientes.
              </p>
            </div>

            {activeDoc.questions.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No hay preguntas en este documento. Carga otro archivo o regenera.
              </div>
            ) : (
              <div className="space-y-3">
                {activeDoc.questions.map((q, idx) => (
                  <div
                    key={q.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-blue-200 transition space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-2.5">
                        <span className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                          {q.prompt}
                        </h4>
                      </div>

                      <button
                        onClick={() => removeQuestionFromDocument(activeDoc.id, q.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition"
                        title="Quitar pregunta"
                      >
                        <Trash2 className="w-4 h-4 text-rose-500" />
                      </button>
                    </div>

                    {/* 4 Options Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-8 text-xs">
                      {q.options.map((opt, oIdx) => {
                        const isCorrect = oIdx === q.correctOptionIndex;
                        return (
                          <div
                            key={oIdx}
                            className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                              isCorrect
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-semibold'
                                : 'bg-white border-slate-200 text-slate-700'
                            }`}
                          >
                            <span
                              className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-bold shrink-0 ${
                                isCorrect ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {String.fromCharCode(65 + oIdx)}
                            </span>
                            <span className="flex-1 leading-snug">{opt}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2 Content: PARTICIPANTES */}
        {docTab === 'participantes' && (
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between pb-2">
              <p className="text-xs text-slate-500">
                Lista de cadetes y alumnos que han participado en esta evaluación.
              </p>
            </div>

            {participantsList.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <Users className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs font-semibold text-slate-700">
                  Aún no hay participantes en este examen
                </p>
                <p className="text-[11px] text-slate-500">
                  Presiona el botón "Lanzar Sala QR / Examen" para generar el código y proyectarlo a tus alumnos.
                </p>
                <button
                  onClick={handleOpenLaunchModal}
                  className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
                >
                  Lanzar Sala QR
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {participantsList.map((part) => (
                  <div
                    key={part.id}
                    className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center gap-3"
                  >
                    <div
                      className={`w-10 h-10 rounded-2xl ${part.avatarBg} text-white flex items-center justify-center text-xl shadow-xs shrink-0`}
                    >
                      {part.avatarEmoji}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-slate-900 truncate">
                        {part.name}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Hora de ingreso: {part.joinedAt}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3 Content: RANKING Y RESULTADOS */}
        {docTab === 'ranking' && (
          <div className="p-6 space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Ranking Oficial de la Actividad
              </h3>
              <p className="text-xs text-slate-500">
                Puntuaciones calculadas según precisión de respuestas y tiempo de resolución
              </p>
            </div>

            {sortedParticipants.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <Trophy className="w-8 h-8 text-amber-500 mx-auto" />
                <p className="text-xs font-semibold text-slate-700">
                  Aún no hay resultados registrados
                </p>
                <p className="text-[11px] text-slate-500">
                  Cuando los alumnos completen la actividad QR, aquí verás el podio de 1°, 2° y 3° lugar junto con el listado de puntuaciones.
                </p>
              </div>
            ) : (
              <>
                {/* Top 3 Podium */}
                <div className="grid grid-cols-3 gap-3 max-w-lg mx-auto text-center pt-2">
                  {/* 2nd Place */}
                  {sortedParticipants[1] && (
                    <div className="p-4 rounded-2xl bg-slate-100 border border-slate-300 flex flex-col items-center">
                      <span className="text-lg font-black text-slate-400">2°</span>
                      <div
                        className={`w-12 h-12 rounded-2xl ${sortedParticipants[1].avatarBg} text-white flex items-center justify-center text-2xl my-2 shadow`}
                      >
                        {sortedParticipants[1].avatarEmoji}
                      </div>
                      <div className="text-xs font-bold text-slate-900 truncate max-w-full">
                        {sortedParticipants[1].name}
                      </div>
                      <div className="text-xs font-mono font-bold text-blue-600 mt-1">
                        {sortedParticipants[1].score} pts
                      </div>
                    </div>
                  )}

                  {/* 1st Place */}
                  {sortedParticipants[0] && (
                    <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-400 shadow-md flex flex-col items-center">
                      <span className="text-xl font-black text-amber-600">1° Oro</span>
                      <div
                        className={`w-14 h-14 rounded-2xl ${sortedParticipants[0].avatarBg} text-white flex items-center justify-center text-3xl my-2 shadow-lg ring-2 ring-amber-400`}
                      >
                        {sortedParticipants[0].avatarEmoji}
                      </div>
                      <div className="text-xs font-extrabold text-slate-900 truncate max-w-full">
                        {sortedParticipants[0].name}
                      </div>
                      <div className="text-sm font-mono font-black text-amber-600 mt-1">
                        {sortedParticipants[0].score} pts
                      </div>
                    </div>
                  )}

                  {/* 3rd Place */}
                  {sortedParticipants[2] && (
                    <div className="p-4 rounded-2xl bg-orange-50 border border-orange-200 flex flex-col items-center">
                      <span className="text-lg font-black text-amber-800">3°</span>
                      <div
                        className={`w-12 h-12 rounded-2xl ${sortedParticipants[2].avatarBg} text-white flex items-center justify-center text-2xl my-2 shadow`}
                      >
                        {sortedParticipants[2].avatarEmoji}
                      </div>
                      <div className="text-xs font-bold text-slate-900 truncate max-w-full">
                        {sortedParticipants[2].name}
                      </div>
                      <div className="text-xs font-mono font-bold text-amber-800 mt-1">
                        {sortedParticipants[2].score} pts
                      </div>
                    </div>
                  )}
                </div>

                {/* Full Table */}
                <div className="border border-slate-200 rounded-2xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                        <th className="py-2.5 px-3">Posición</th>
                        <th className="py-2.5 px-3">Participante</th>
                        <th className="py-2.5 px-3">Puntuación</th>
                        <th className="py-2.5 px-3">Aciertos</th>
                        <th className="py-2.5 px-3">Tiempo Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {sortedParticipants.map((p, idx) => (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-bold text-slate-800">{idx + 1}°</td>
                          <td className="py-2.5 px-3 font-bold text-slate-900 flex items-center gap-2">
                            <span className={`w-6 h-6 rounded-md ${p.avatarBg} text-white flex items-center justify-center text-xs`}>
                              {p.avatarEmoji}
                            </span>
                            <span>{p.name}</span>
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-blue-600">
                            {p.score} pts
                          </td>
                          <td className="py-2.5 px-3 font-semibold text-emerald-600">
                            {p.correctAnswers} correctas
                          </td>
                          <td className="py-2.5 px-3 text-slate-500">{p.totalTimeSeconds}s</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}
      </div>
      )}

      {/* ============================================================ */}
      {/* SIMPLE QR LAUNCH MODAL */}
      {/* ============================================================ */}
      {showQrModal && activeRoom && activeDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6 text-center">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="text-left">
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
                  Sala de Evaluación en Vivo
                </span>
                <h3 className="text-base font-bold text-slate-900 font-heading">
                  {activeDoc.title}
                </h3>
              </div>
              <button
                onClick={() => setShowQrModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold p-1"
              >
                ✕
              </button>
            </div>

            {/* QR Code */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 inline-block shadow-inner mx-auto">
              <QrCodeSvg value={`https://evaluaia.edu/sala/${activeRoom.roomCode}`} size={200} />
            </div>

            {/* PIN Code */}
            <div className="p-3 bg-slate-900 text-white rounded-2xl flex items-center justify-between max-w-xs mx-auto">
              <span className="text-xs text-slate-400 font-semibold">Código de Sala:</span>
              <span className="text-xl font-mono font-black text-amber-400 tracking-wider">
                {activeRoom.roomCode}
              </span>
            </div>

            {/* Simple Time Setting */}
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-left space-y-2">
              <div className="flex justify-between text-xs font-bold text-slate-800">
                <span>Tiempo límite por pregunta:</span>
                <span className="text-blue-600 font-extrabold">{timeSeconds} segundos</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[15, 20, 30].map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => setTimeSeconds(sec)}
                    className={`py-1.5 rounded-xl text-xs font-bold border transition ${
                      timeSeconds === sec
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {sec} seg
                  </button>
                ))}
              </div>
            </div>

            {/* Connected Count & Actions */}
            <div className="space-y-3">
              <div className="text-xs text-slate-600 font-medium flex items-center justify-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>{participantsList.length} participantes esperando en la sala</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowQrModal(false);
                    startParticipantFlow(activeRoom.id);
                  }}
                  className="py-3 px-4 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-900 border border-amber-400 font-bold text-xs transition"
                >
                  Probar como Alumno
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleStartExamNow();
                    setShowQrModal(false);
                    showToast('success', '¡Actividad iniciada con éxito!');
                  }}
                  className="py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition flex items-center justify-center gap-1.5"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>Iniciar Actividad</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
