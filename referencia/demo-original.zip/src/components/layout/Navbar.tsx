import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  Sparkles,
  UserCheck,
  ChevronDown,
  Play,
  RotateCcw,
  LogOut,
  ShieldCheck,
  GraduationCap,
} from 'lucide-react';

interface NavbarProps {
  onToggleMobileMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = () => {
  const {
    currentUser,
    currentRole,
    switchRole,
    logout,
    resetAllData,
    startParticipantFlow,
  } = useApp();

  const [showRoleMenu, setShowRoleMenu] = useState(false);

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-14 px-4 md:px-6 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Brand logo & role indicator */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black text-xs shadow-sm">
            AI
          </div>
          <div>
            <h2 className="text-sm font-extrabold text-slate-900 leading-tight">
              Evalua<span className="text-blue-600">IA</span>
            </h2>
            <p className="text-[10px] text-slate-500 font-medium">
              {currentRole === 'admin' ? 'Panel de Administrador' : 'Panel de Docente / Supervisor'}
            </p>
          </div>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Test as student button */}
        <button
          onClick={() => startParticipantFlow()}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded-xl transition"
          title="Abrir como participante alumno"
        >
          <Play className="w-3.5 h-3.5 fill-amber-700 text-amber-700" />
          <span>Probar como Alumno (QR)</span>
        </button>

        {/* Simplified Role Switcher (Docente vs Admin) */}
        <div className="relative">
          <button
            onClick={() => setShowRoleMenu(!showRoleMenu)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition border border-slate-200"
          >
            <UserCheck className="w-3.5 h-3.5 text-blue-600" />
            <span className="capitalize">
              {currentRole === 'admin' ? 'Administrador' : 'Docente / Supervisor'}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {showRoleMenu && (
            <div className="absolute right-0 mt-2 w-52 bg-white rounded-2xl shadow-xl border border-slate-200 p-1.5 z-50 animate-in fade-in">
              <button
                onClick={() => {
                  switchRole('docente');
                  setShowRoleMenu(false);
                }}
                className={`w-full text-left px-3 py-2 text-xs rounded-xl flex items-center justify-between transition ${
                  currentRole === 'docente' ? 'bg-blue-50 text-blue-700 font-bold' : 'hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-emerald-600" />
                  <span>Docente / Supervisor</span>
                </span>
                {currentRole === 'docente' && <span className="text-[10px]">Activo</span>}
              </button>

              <button
                onClick={() => {
                  switchRole('admin');
                  setShowRoleMenu(false);
                }}
                className={`w-full text-left px-3 py-2 text-xs rounded-xl flex items-center justify-between transition ${
                  currentRole === 'admin' ? 'bg-blue-50 text-blue-700 font-bold' : 'hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>Administrador</span>
                </span>
                {currentRole === 'admin' && <span className="text-[10px]">Activo</span>}
              </button>
            </div>
          )}
        </div>

        {/* Reset button */}
        <button
          onClick={resetAllData}
          className="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-slate-100 transition"
          title="Restablecer datos originales"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {/* Logout */}
        <button
          onClick={logout}
          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition"
          title="Cerrar sesión"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
