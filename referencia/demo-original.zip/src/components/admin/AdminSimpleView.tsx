import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { User } from '../../types';
import { QrCodeSvg } from '../common/QrCodeSvg';
import {
  FileText,
  Users,
  QrCode,
  Cpu,
  Trash2,
  Plus,
  CheckCircle2,
  Sparkles,
  Server,
  Zap,
  Activity,
  Play,
  Trophy,
  Crown,
  Award,
  ChevronRight,
  TrendingUp,
  BarChart2,
} from 'lucide-react';

export const AdminSimpleView: React.FC = () => {
  const {
    documents,
    deleteDocument,
    users,
    createUser,
    toggleUserStatus,
    rooms,
    startRoomActivity,
    aiProviders,
    setActiveAiProvider,
    showToast,
    startParticipantFlow,
  } = useApp();

  const [adminTab, setAdminTab] = useState<'documentos' | 'usuarios' | 'evaluaciones' | 'ia'>('documentos');

  // New user form state
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userRole, setUserRole] = useState<'docente' | 'admin'>('docente');

  // Selected Room for Ranking View
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(() => rooms[0]?.id || null);

  // QR Modal
  const [selectedRoomCode, setSelectedRoomCode] = useState<string | null>(null);

  // Latency test state
  const [testingAi, setTestingAi] = useState<string | null>(null);

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !userEmail.trim()) return;
    createUser(userName, userEmail, userRole);
    setUserName('');
    setUserEmail('');
  };

  const handleTestLatency = (providerId: string, ms: number) => {
    setTestingAi(providerId);
    setTimeout(() => {
      setTestingAi(null);
      showToast('success', `Conexión verificada: ${ms}ms de latencia`);
    }, 700);
  };

  // Active room and document for ranking calculation
  const activeRankingRoom = useMemo(() => {
    return rooms.find((r) => r.id === selectedRoomId) || rooms[0] || null;
  }, [rooms, selectedRoomId]);

  const activeDocForRoom = useMemo(() => {
    if (!activeRankingRoom) return null;
    return documents.find((d) => d.id === activeRankingRoom.documentId) || null;
  }, [documents, activeRankingRoom]);

  const totalQuestionsInDoc = activeDocForRoom?.questions?.length || 4;

  const rankedParticipants = useMemo(() => {
    if (!activeRankingRoom) return [];
    return [...activeRankingRoom.participants]
      .map((p) => {
        const pct = p.percentage !== undefined
          ? p.percentage
          : (totalQuestionsInDoc > 0 ? Math.round((p.correctAnswers / totalQuestionsInDoc) * 100) : 0);
        return {
          ...p,
          calculatedPct: pct,
        };
      })
      .sort((a, b) => {
        // Sort strictly by percentage from highest to lowest
        if (b.calculatedPct !== a.calculatedPct) {
          return b.calculatedPct - a.calculatedPct;
        }
        return b.score - a.score;
      });
  }, [activeRankingRoom, totalQuestionsInDoc]);

  const averagePct = useMemo(() => {
    if (rankedParticipants.length === 0) return 0;
    const sum = rankedParticipants.reduce((acc, p) => acc + p.calculatedPct, 0);
    return Math.round(sum / rankedParticipants.length);
  }, [rankedParticipants]);

  const bestPct = useMemo(() => {
    if (rankedParticipants.length === 0) return 0;
    return rankedParticipants[0].calculatedPct;
  }, [rankedParticipants]);

  return (
    <div className="space-y-6">
      {/* Tab Navigation: Direct and Simple */}
      <div className="flex border-b border-slate-200 gap-2 bg-white px-4 py-2 rounded-2xl shadow-sm">
        <button
          onClick={() => setAdminTab('documentos')}
          className={`py-2 px-4 text-xs font-bold rounded-xl transition flex items-center gap-2 ${
            adminTab === 'documentos'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Documentos PDF ({documents.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('usuarios')}
          className={`py-2 px-4 text-xs font-bold rounded-xl transition flex items-center gap-2 ${
            adminTab === 'usuarios'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Crear y Gestionar Usuarios ({users.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('evaluaciones')}
          className={`py-2 px-4 text-xs font-bold rounded-xl transition flex items-center gap-2 ${
            adminTab === 'evaluaciones'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <QrCode className="w-4 h-4" />
          <span>Evaluaciones & QR ({rooms.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('ia')}
          className={`py-2 px-4 text-xs font-bold rounded-xl transition flex items-center gap-2 ${
            adminTab === 'ia'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>Motores de IA ({aiProviders.length})</span>
        </button>
      </div>

      {/* 1. DOCUMENTOS PDF TAB */}
      {adminTab === 'documentos' && (
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900 font-heading">
              Documentos Cargados en el Sistema
            </h2>
            <span className="text-xs text-slate-500">
              Vista administrativa de materiales subidos por los docentes
            </span>
          </div>

          {documents.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs bg-slate-50 rounded-2xl border border-slate-200">
              No hay documentos cargados en el sistema todavía. Los documentos subidos por los docentes aparecerán aquí.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="py-2.5 px-3">Documento</th>
                    <th className="py-2.5 px-3">Subido Por</th>
                    <th className="py-2.5 px-3">Fecha</th>
                    <th className="py-2.5 px-3">Tamaño</th>
                    <th className="py-2.5 px-3">Preguntas</th>
                    <th className="py-2.5 px-3 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {documents.map((doc) => (
                    <tr key={doc.id} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3 font-bold text-slate-900">
                        <div>{doc.title}</div>
                        <div className="text-[11px] text-slate-400 font-normal">{doc.fileName}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-700 font-medium">{doc.uploadedBy}</td>
                      <td className="py-3 px-3 text-slate-500">{doc.uploadDate}</td>
                      <td className="py-3 px-3 text-slate-500">{doc.fileSize}</td>
                      <td className="py-3 px-3 font-semibold text-blue-600">
                        {doc.questions.length} preguntas
                      </td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => deleteDocument(doc.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                          title="Eliminar documento"
                        >
                          <Trash2 className="w-4 h-4 text-rose-500" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 2. CREAR Y GESTIONAR USUARIOS TAB */}
      {adminTab === 'usuarios' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Create User Form (5 cols) */}
          <form
            onSubmit={handleCreateUser}
            className="md:col-span-5 p-6 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-4"
          >
            <h3 className="text-sm font-bold text-slate-900 font-heading pb-2 border-b border-slate-100">
              Crear Nueva Cuenta (Docente / Supervisor)
            </h3>
            <p className="text-[11px] text-slate-500">
              Crea el usuario para que el docente pueda ingresar y cargar sus documentos.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nombre y Apellido
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Ej. Prof. Javier Salazar"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:border-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Correo Institucional
              </label>
              <input
                type="email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                placeholder="javier@evaluaia.edu"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:border-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Rol
              </label>
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as 'docente' | 'admin')}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none"
              >
                <option value="docente">Docente / Supervisor</option>
                <option value="admin">Administrador</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-sm flex items-center justify-center gap-1.5 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Crear Usuario</span>
            </button>
          </form>

          {/* Users List Table (7 cols) */}
          <div className="md:col-span-7 p-6 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 font-heading pb-2 border-b border-slate-100">
              Cuentas Registradas ({users.length})
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="py-2.5 px-2">Usuario</th>
                    <th className="py-2.5 px-2">Rol</th>
                    <th className="py-2.5 px-2">Estado</th>
                    <th className="py-2.5 px-2 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-2">
                        <div className="font-bold text-slate-900">{u.name}</div>
                        <div className="text-[11px] text-slate-400">{u.email}</div>
                      </td>
                      <td className="py-2.5 px-2 capitalize font-medium text-slate-700">
                        {u.role === 'admin' ? 'Administrador' : 'Docente / Supervisor'}
                      </td>
                      <td className="py-2.5 px-2">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            u.status === 'active'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {u.status === 'active' ? 'Activo' : 'Desactivado'}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <button
                          onClick={() => toggleUserStatus(u.id)}
                          className="px-2 py-1 text-[11px] font-semibold text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition"
                        >
                          {u.status === 'active' ? 'Desactivar' : 'Activar'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. EVALUACIONES & QR TAB */}
      {adminTab === 'evaluaciones' && (
        <div className="space-y-6">
          {/* Header */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 font-heading">
                Evaluaciones y Salas QR
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Selecciona un documento PDF para consultar el ranking oficial de participantes clasificado de mayor a menor porcentaje (%).
              </p>
            </div>
            {activeRankingRoom && (
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setSelectedRoomCode(activeRankingRoom.roomCode)}
                  className="px-3.5 py-2 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border border-blue-200"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Ver Código QR</span>
                </button>
                <button
                  onClick={() => startParticipantFlow(activeRankingRoom.id)}
                  className="px-3.5 py-2 bg-amber-50 text-amber-800 hover:bg-amber-100 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border border-amber-200"
                >
                  <Play className="w-3.5 h-3.5 fill-amber-700 text-amber-700" />
                  <span>Probar como Alumno</span>
                </button>
              </div>
            )}
          </div>

          {rooms.length === 0 ? (
            <div className="p-10 text-center bg-white rounded-3xl border border-slate-200 space-y-3 shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <QrCode className="w-6 h-6" />
              </div>
              <p className="text-xs font-semibold text-slate-700">
                No hay salas de evaluación QR creadas todavía
              </p>
              <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                Cuando un docente genere una sala para un documento PDF, aparecerá en esta lista para consultar su ranking.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Documentos PDF disponibles para consultar ranking */}
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                  Documentos PDF con Evaluación ({rooms.length}) — Haz clic para ver ranking:
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {rooms.map((room) => {
                    const isSelected = room.id === activeRankingRoom?.id;
                    return (
                      <button
                        key={room.id}
                        type="button"
                        onClick={() => setSelectedRoomId(room.id)}
                        className={`text-left p-4 rounded-2xl border transition flex flex-col justify-between gap-3 ${
                          isSelected
                            ? 'bg-blue-50/70 border-blue-500 ring-2 ring-blue-500/20 shadow-sm'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50 shadow-xs'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                              isSelected ? 'bg-blue-600 text-white' : 'bg-red-50 text-red-600 border border-red-100'
                            }`}
                          >
                            <FileText className="w-5 h-5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <span className="text-[10px] font-mono font-bold text-blue-600 block">
                              Sala: {room.roomCode}
                            </span>
                            <h3 className="text-xs font-extrabold text-slate-900 truncate mt-0.5 leading-snug">
                              {room.documentTitle}
                            </h3>
                            <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-500">
                              <span className="flex items-center gap-1 font-semibold text-slate-700">
                                <Users className="w-3 h-3 text-slate-400" />
                                {room.participants.length} participantes
                              </span>
                              <span>•</span>
                              <span>{room.timePerQuestionSeconds}s/preg</span>
                            </div>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                          <span
                            className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              room.status === 'en_curso'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {room.status === 'en_curso' ? 'En Curso' : 'Finalizada'}
                          </span>
                          <span className={`font-bold flex items-center gap-0.5 ${isSelected ? 'text-blue-700' : 'text-slate-500'}`}>
                            {isSelected ? 'Ranking Activo' : 'Ver Ranking'}
                            <ChevronRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Ranking detallado de participantes clasificado de mayor a menor % */}
              {activeRankingRoom && (
                <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-5 animate-in fade-in">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                    <div className="space-y-1">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 text-[10px] font-extrabold uppercase tracking-wide">
                        <Trophy className="w-3 h-3 text-amber-500" />
                        <span>Ranking Oficial de Participantes</span>
                      </div>
                      <h3 className="text-base sm:text-lg font-black text-slate-900 font-heading">
                        {activeRankingRoom.documentTitle}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Clasificación ordenada estrictamente de mayor a menor porcentaje de aciertos (%)
                      </p>
                    </div>

                    {/* Metric Badges */}
                    <div className="flex items-center gap-2">
                      <div className="px-3 py-1.5 bg-slate-50 rounded-xl border border-slate-200 text-center">
                        <span className="text-[10px] text-slate-400 block font-bold">Total Alumnos</span>
                        <span className="text-xs font-black text-slate-800">{rankedParticipants.length}</span>
                      </div>
                      <div className="px-3 py-1.5 bg-emerald-50 rounded-xl border border-emerald-200 text-center">
                        <span className="text-[10px] text-emerald-600 block font-bold">Mejor %</span>
                        <span className="text-xs font-black text-emerald-800">{bestPct}%</span>
                      </div>
                      <div className="px-3 py-1.5 bg-blue-50 rounded-xl border border-blue-200 text-center">
                        <span className="text-[10px] text-blue-600 block font-bold">Promedio %</span>
                        <span className="text-xs font-black text-blue-800">{averagePct}%</span>
                      </div>
                    </div>
                  </div>

                  {rankedParticipants.length === 0 ? (
                    <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <Users className="w-8 h-8 text-slate-400 mx-auto" />
                      <p className="text-xs font-bold text-slate-700">
                        Aún no hay participantes en esta evaluación
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Comparte el código QR ({activeRankingRoom.roomCode}) o haz clic en "Probar como Alumno" para registrar respuestas.
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                            <th className="py-3 px-3">Posición</th>
                            <th className="py-3 px-3">Participante</th>
                            <th className="py-3 px-3">Rendimiento (%)</th>
                            <th className="py-3 px-3">Aciertos</th>
                            <th className="py-3 px-3">Puntaje</th>
                            <th className="py-3 px-3 text-right">Tiempo</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {rankedParticipants.map((part, idx) => {
                            const isFirst = idx === 0;
                            const isSecond = idx === 1;
                            const isThird = idx === 2;

                            return (
                              <tr
                                key={part.id}
                                className={`transition ${
                                  isFirst
                                    ? 'bg-amber-50/40 hover:bg-amber-50/70 font-medium'
                                    : 'hover:bg-slate-50'
                                }`}
                              >
                                {/* Posición */}
                                <td className="py-3 px-3">
                                  {isFirst ? (
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-black text-xs shadow-xs">
                                      <Crown className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
                                      <span>1° Oro</span>
                                    </span>
                                  ) : isSecond ? (
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-200 text-slate-800 font-bold text-xs">
                                      <Award className="w-3.5 h-3.5 text-slate-600" />
                                      <span>2° Plata</span>
                                    </span>
                                  ) : isThird ? (
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 font-bold text-xs">
                                      <Award className="w-3.5 h-3.5 text-amber-700" />
                                      <span>3° Bronce</span>
                                    </span>
                                  ) : (
                                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-bold text-xs">
                                      {idx + 1}°
                                    </span>
                                  )}
                                </td>

                                {/* Participante */}
                                <td className="py-3 px-3">
                                  <div className="flex items-center gap-2.5">
                                    <div
                                      className={`w-8 h-8 rounded-xl ${part.avatarBg} text-white flex items-center justify-center text-sm shadow-xs shrink-0`}
                                    >
                                      {part.avatarEmoji}
                                    </div>
                                    <div>
                                      <div className="font-extrabold text-slate-900 text-xs">
                                        {part.name}
                                      </div>
                                      <div className="text-[10px] text-slate-400">
                                        Ingreso: {part.joinedAt}
                                      </div>
                                    </div>
                                  </div>
                                </td>

                                {/* Porcentaje de mayor a menor con barra visual */}
                                <td className="py-3 px-3 min-w-[170px]">
                                  <div className="space-y-1">
                                    <div className="flex items-center justify-between">
                                      <span
                                        className={`font-black text-xs ${
                                          part.calculatedPct >= 70
                                            ? 'text-emerald-700'
                                            : part.calculatedPct >= 50
                                            ? 'text-amber-700'
                                            : 'text-rose-600'
                                        }`}
                                      >
                                        {part.calculatedPct}%
                                      </span>
                                      <span className="text-[10px] text-slate-400">
                                        {part.calculatedPct >= 70 ? 'Aprobado' : 'Reforzar'}
                                      </span>
                                    </div>
                                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                                      <div
                                        className={`h-full rounded-full transition-all duration-300 ${
                                          part.calculatedPct >= 70
                                            ? 'bg-emerald-500'
                                            : part.calculatedPct >= 50
                                            ? 'bg-amber-500'
                                            : 'bg-rose-500'
                                        }`}
                                        style={{ width: `${part.calculatedPct}%` }}
                                      />
                                    </div>
                                  </div>
                                </td>

                                {/* Aciertos */}
                                <td className="py-3 px-3">
                                  <span className="inline-flex items-center gap-1 font-bold text-slate-700">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>{part.correctAnswers} / {totalQuestionsInDoc}</span>
                                  </span>
                                </td>

                                {/* Puntaje */}
                                <td className="py-3 px-3 font-mono font-bold text-blue-600">
                                  {part.score.toLocaleString()} pts
                                </td>

                                {/* Tiempo */}
                                <td className="py-3 px-3 text-right font-mono text-slate-500">
                                  {part.totalTimeSeconds}s
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 4. MOTORES DE IA TAB */}
      {adminTab === 'ia' && (
        <div className="space-y-4">
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm">
            <h2 className="text-base font-bold text-slate-900 font-heading">
              Motores de Inteligencia Artificial
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Selecciona el proveedor activo para el análisis y formulación de preguntas
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {aiProviders.map((prov) => {
              const isActive = prov.status === 'activo';
              return (
                <div
                  key={prov.id}
                  className={`p-6 rounded-3xl border bg-white flex flex-col justify-between space-y-4 ${
                    isActive ? 'border-blue-600 shadow-md ring-2 ring-blue-500/20' : 'border-slate-200'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center">
                        {prov.id === 'gemini' ? (
                          <Sparkles className="w-5 h-5 text-blue-600" />
                        ) : prov.id === 'openrouter' ? (
                          <Zap className="w-5 h-5 text-purple-600" />
                        ) : (
                          <Server className="w-5 h-5 text-emerald-600" />
                        )}
                      </div>
                      {isActive && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                          Activo
                        </span>
                      )}
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{prov.name}</h4>
                      <p className="text-xs font-mono text-slate-500 mt-0.5">{prov.model}</p>
                      <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                        {prov.description}
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleTestLatency(prov.id, prov.latencyMs)}
                      className="py-2 text-xs font-semibold rounded-xl border border-slate-200 hover:bg-slate-50 flex items-center justify-center gap-1 text-slate-700"
                    >
                      <Activity className="w-3.5 h-3.5 text-blue-600" />
                      <span>{testingAi === prov.id ? 'Probando...' : 'Test'}</span>
                    </button>

                    {!isActive ? (
                      <button
                        onClick={() => setActiveAiProvider(prov.id)}
                        className="py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        Activar
                      </button>
                    ) : (
                      <div className="py-2 text-xs font-bold rounded-xl bg-emerald-50 text-emerald-700 text-center border border-emerald-200">
                        En uso
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* QR Viewer Modal */}
      {selectedRoomCode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-900">
              Código QR de Acceso
            </h3>
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 inline-block shadow-inner">
              <QrCodeSvg value={`https://evaluaia.edu/sala/${selectedRoomCode}`} size={200} />
            </div>
            <div className="p-2.5 bg-slate-900 text-amber-400 font-mono font-black text-lg rounded-xl">
              {selectedRoomCode}
            </div>
            <button
              onClick={() => setSelectedRoomCode(null)}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
            >
              Cerrar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
