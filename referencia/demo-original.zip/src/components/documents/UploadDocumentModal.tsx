import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Question } from '../../types';
import {
  X,
  UploadCloud,
  FileText,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Brain,
  Layers,
  Cpu,
  Trash2,
  Check,
  Sliders,
  HelpCircle,
  Hash,
} from 'lucide-react';

interface UploadDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UploadDocumentModal: React.FC<UploadDocumentModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { addDocumentWithQuestions } = useApp();

  const [docTitle, setDocTitle] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [fileObj, setFileObj] = useState<File | null>(null);

  // Configurable number of questions to generate
  const [numQuestions, setNumQuestions] = useState<number>(5);

  const [step, setStep] = useState<'upload' | 'processing' | 'review'>('upload');
  const [currentStage, setCurrentStage] = useState(0);
  const [progressPercent, setProgressPercent] = useState(0);

  // Generated questions draft (the teacher can discard any they don't like!)
  const [draftQuestions, setDraftQuestions] = useState<Question[]>([]);

  const stages = [
    { label: 'Cargando documento PDF...', icon: <UploadCloud className="w-4 h-4" /> },
    { label: 'Extrayendo texto y OCR...', icon: <FileText className="w-4 h-4" /> },
    { label: 'Analizando conceptos con IA...', icon: <Brain className="w-4 h-4" /> },
    { label: 'Identificando temas clave...', icon: <Layers className="w-4 h-4" /> },
    { label: `Formulando ${numQuestions} preguntas y opciones...`, icon: <Cpu className="w-4 h-4" /> },
    { label: `¡${numQuestions} preguntas generadas!`, icon: <CheckCircle2 className="w-4 h-4" /> },
  ];

  // Dynamically generate exact number of questions tailored to the document title and count
  const generateQuestionsForTitle = (title: string, count: number): Question[] => {
    const cleanTitle = title.trim() || 'Documento Académico';
    const lower = cleanTitle.toLowerCase();
    const targetCount = Math.max(1, Math.min(20, count));

    let pool: Omit<Question, 'id'>[] = [];

    if (lower.includes('dactilo') || lower.includes('forense') || lower.includes('criminal')) {
      pool = [
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Cuáles son los tres postulados científicos fundamentales que sustentan la inmutabilidad de las huellas dactilares?`,
          options: [
            'Perennidad, inmutabilidad y variedad infinita',
            'Simetría anatómica, grosor epidérmico y elasticidad',
            'Temperatura dérmica, coloración y profundidad capilar',
            'Densidad de poros, rigidez muscular y linealidad'
          ],
          correctOptionIndex: 0,
          explanation: 'Las crestas papilares se forman en el cuarto mes de gestación y permanecen inalterables hasta la putrefacción cadavérica.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `En la clasificación dactiloscópica, ¿cómo se denomina la minuta donde una cresta papilar se divide en dos ramas distintas?`,
          options: [
            'Bifurcación u horquilla',
            'Islote o punto aislado',
            'Delta periférico cerrado',
            'Interrupción transversal'
          ],
          correctOptionIndex: 0,
          explanation: 'La bifurcación es una de las características morfológicas cardinales utilizadas en el cotejo pericial y el AFIS.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Qué reactivo físico en polvo es el más adecuado para revelar huellas latentes sobre superficies lisas no porosas como vidrios o metales?`,
          options: [
            'Polvo magnético negro o de grafito fino',
            'Nitrato de plata en solución ácida',
            'Solución acuosa de sulfato de cobre',
            'Luminol con activador alcalino'
          ],
          correctOptionIndex: 0,
          explanation: 'Los polvos mecánicos se adhieren por adhesión física a las secreciones sebáceas y sudoríparas depositadas en superficies lisas.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿A partir de cuántos puntos característicos coincidentes se considera una identificación plena e incontrovertible en tribunales?`,
          options: [
            'Entre 10 y 12 puntos característicos sin discrepancias',
            'Basta con 2 puntos morfológicos generales',
            'Mínimo 50 puntos microscópicos de crestas',
            'Solamente requiere la coincidencia del tipo fundamental'
          ],
          correctOptionIndex: 0,
          explanation: 'El estándar pericial homologado internacionalmente suele requerir entre 10 y 12 puntos característicos coincidentes.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Cuál es la función primordial del sistema biométrico automatizado AFIS en el laboratorio pericial?`,
          options: [
            'Búsqueda algorítmica y cotejo automatizado de minucias en bases dactilares',
            'Destrucción inmediata de los indicios físicos recolectados',
            'Redacción automática de la sentencia penal',
            'Estimación aproximada del grupo sanguíneo del sospechoso'
          ],
          correctOptionIndex: 0,
          explanation: 'El AFIS procesa matemáticamente la orientación y coordenadas relativas de las minucias papilares.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Qué tipo de reactivo químico se utiliza con preferencia para el revelado de huellas sobre papel, cartón o superficies porosas?`,
          options: [
            'Ninhidrina o DFO en cámara climática',
            'Polvo magnético pesado con pincel de fibra',
            'Solución de permanganato de potasio',
            'Cera sintética caliente'
          ],
          correctOptionIndex: 0,
          explanation: 'La ninhidrina reacciona con los aminoácidos presentes en la transpiración humana formando púrpura de Ruhemann.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `En la escena del crimen, ¿cuál es el procedimiento pericial obligatorio antes de aplicar polvos o reactivos?`,
          options: [
            'Fijación fotográfica métrica preliminar e iluminación rasante',
            'Limpieza de la superficie con solvente clorado',
            'Manipulación directa con guantes de lana',
            'Exposición directa a altas temperaturas'
          ],
          correctOptionIndex: 0,
          explanation: 'La fijación fotográfica con testigo métrico preserva la escena en su estado original antes de cualquier intervención física.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Cómo se define el término lofoscopía en el contexto de la criminalística forense?`,
          options: [
            'Estudio sistemático de los dibujos formados por las crestas papilares de la piel',
            'Análisis toxicológico de fluidos corporales',
            'Examen de autenticidad de firmas manuscritas',
            'Técnica balística de reconstrucción de trayectorias'
          ],
          correctOptionIndex: 0,
          explanation: 'La lofoscopía abarca la dactiloscopía (dedos), quiroscopía (palmas) y pelmatoscopía (plantas de pies).',
        },
      ];
    } else if (lower.includes('penal') || lower.includes('derecho') || lower.includes('procesal')) {
      pool = [
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `Según los fundamentos de ${cleanTitle}, ¿cuál es el principio procesal que garantiza que nadie sea sancionado sin juicio previo?`,
          options: [
            'Principio de Juicio Previo y Debido Proceso',
            'Principio de Oportunidad Reglada',
            'Presunción de Imputabilidad Tácita',
            'Discrecionalidad Policial Plena'
          ],
          correctOptionIndex: 0,
          explanation: 'El debido proceso es una garantía constitucional rectora de todo procedimiento penal.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `En el marco de ${cleanTitle}, ¿qué requisito indispensable valida la cadena de custodia de las evidencias?`,
          options: [
            'Registro cronológico ininterrumpido de trazabilidad e identidad de responsables',
            'Firma exclusivamente del testigo civil presencial',
            'Embalaje sin rotular hasta la audiencia de juicio',
            'Almacenamiento temporal en recintos no periciales'
          ],
          correctOptionIndex: 0,
          explanation: 'La cadena de custodia exige certificar el tracto sucesivo de custodia y conservación intacta.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Cuál es el estándar probatorio exigido para fundamentar una sentencia condenatoria firme?`,
          options: [
            'Certeza fundada más allá de toda duda razonable',
            'Simple sospecha o indicio aislado',
            'Unanimidad de medios periodísticos',
            'Declaración indagatoria sin peritajes'
          ],
          correctOptionIndex: 0,
          explanation: 'La condena requiere convicción razonada y superación plena de toda duda objetiva.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿En qué consiste el principio de presunción de inocencia en el régimen acusatorio?`,
          options: [
            'Toda persona es considerada inocente hasta que una sentencia firme declare su culpabilidad',
            'El imputado debe demostrar fehacientemente que no cometió el delito',
            'La prisión preventiva es la regla general en todas las investigaciones',
            'El juez asume la dirección de la acusación pública'
          ],
          correctOptionIndex: 0,
          explanation: 'La carga de la prueba recae exclusivamente sobre la parte acusadora.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Qué efecto procesal tiene la obtención de una prueba con vulneración de derechos fundamentales?`,
          options: [
            'Nulidad e inadmisibilidad procesal (Regla de Exclusión)',
            'Valoración reducida a criterio discrecional del tribunal',
            'Multa pecuniaria al perito sin invalidar el elemento',
            'Convalidación tácita si no hay objeción previa'
          ],
          correctOptionIndex: 0,
          explanation: 'La prueba ilícita o fruto del árbol envenenado carece de toda eficacia probatoria.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Cuál es el rol exclusivo del Ministerio Público Fiscal durante la etapa preliminar?`,
          options: [
            'Dirigir la investigación penal y recolectar elementos de convicción',
            'Dictar la sentencia definitiva de mérito',
            'Asumir la defensa técnica del imputado',
            'Aprobar los recursos extraordinarios'
          ],
          correctOptionIndex: 0,
          explanation: 'En el sistema acusatorio, el fiscal investiga y acusa, mientras que el juez de garantías juzga y vela por las garantías.',
        },
      ];
    } else if (lower.includes('ia') || lower.includes('inteligencia') || lower.includes('software') || lower.includes('datos')) {
      pool = [
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `En los conceptos clave de ${cleanTitle}, ¿cuál es el rol primordial del entrenamiento supervisado?`,
          options: [
            'Aprender a mapear entradas con etiquetas de referencia verificadas',
            'Ejecutar scripts aleatorios sin retroalimentación',
            'Eliminar la necesidad de validar métricas de rendimiento',
            'Generar datos sin supervisión algorítmica'
          ],
          correctOptionIndex: 0,
          explanation: 'El aprendizaje supervisado utiliza pares de datos y etiquetas correctas para generalizar predicciones.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `Según ${cleanTitle}, ¿qué técnica mitiga el sobreajuste (overfitting) en modelos predictivos?`,
          options: [
            'Regularización (L1/L2) y validación cruzada (k-fold)',
            'Multiplicar los parámetros sin añadir más muestras',
            'Entrenar indefinidamente con el mismo lote pequeño',
            'Desactivar los conjuntos de prueba y validación'
          ],
          correctOptionIndex: 0,
          explanation: 'La regularización y validación cruzada aseguran que el modelo generalice correctamente sobre datos no vistos.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Qué métrica evalúa el equilibrio armónico entre precisión y exhaustividad?`,
          options: [
            'F1-Score',
            'Tasa bruta de error',
            'Latencia de red',
            'Índice de compresión'
          ],
          correctOptionIndex: 0,
          explanation: 'El F1-Score es la media armónica entre precisión y recall.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Qué mecanismo arquitectónico permite a los modelos Transformer procesar dependencias de largo alcance?`,
          options: [
            'Mecanismo de auto-atención (Self-Attention)',
            'Filtros convolucionales unidimensionales',
            'Memoria swap en disco magnético',
            'Compresión de datos sin pérdida'
          ],
          correctOptionIndex: 0,
          explanation: 'El mecanismo de auto-atención pondera la relevancia mutua de todos los tokens en la secuencia.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Por qué es indispensable separar un conjunto de prueba (test set) independiente?`,
          options: [
            'Para evaluar de forma imparcial la capacidad de generalización sobre datos no observados',
            'Para acelerar el tiempo de cálculo del hardware',
            'Para duplicar el número de parámetros del modelo',
            'Para evitar el uso de funciones de pérdida'
          ],
          correctOptionIndex: 0,
          explanation: 'El conjunto de prueba nunca interviene en el ajuste del modelo para evitar sesgos de optimismo.',
        },
      ];
    } else {
      // Academic / General pool
      pool = [
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Cuál es el postulado central abordado en ${cleanTitle}?`,
          options: [
            `Establecer los principios teóricos, normativos y metodológicos de ${cleanTitle}`,
            'Sustituir toda práctica empírica sin sustento documentado',
            'Limitar la aplicación únicamente a casos hipotéticos no comprobables',
            'Delegar el análisis técnico a entidades externas sin regulación'
          ],
          correctOptionIndex: 0,
          explanation: `El texto de ${cleanTitle} fundamenta sus conceptos en métodos validados y principios rectores.`,
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `Según las directrices de ${cleanTitle}, ¿cuál es la primera fase metodológica recomendada?`,
          options: [
            'Evaluación preliminar diagnóstica y recolección rigurosa de antecedentes',
            'Emisión de conclusiones definitivas de manera inmediata',
            'Omisión del marco conceptual de referencia',
            'Clasificación aleatoria sin verificación de datos'
          ],
          correctOptionIndex: 0,
          explanation: 'Todo abordaje técnico sistemático requiere una fase inicial de verificación y recopilación metódica.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Qué criterio de validez y rigor exige ${cleanTitle} para la corroboración de resultados?`,
          options: [
            'Repetibilidad, trazabilidad y contrastación empírica',
            'Estimaciones intuitivas sin documentación de soporte',
            'Validación mediante votación no vinculante',
            'Aprobación sin registro ni actas formales'
          ],
          correctOptionIndex: 0,
          explanation: 'La consistencia científica y académica exige que los resultados puedan ser auditados y replicados.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `¿Cómo recomienda ${cleanTitle} gestionar las variables críticas o márgenes de incertidumbre?`,
          options: [
            'Mediante protocolos estandarizados de control y calibración periódica',
            'Ignorando las desviaciones menores en los informes',
            'Ajustando los datos de forma subjetiva',
            'Suprimiendo las etapas de revisión por pares'
          ],
          correctOptionIndex: 0,
          explanation: 'El rigor metodológico demanda calibración continua y monitoreo de variaciones sistemáticas.',
        },
        {
          documentId: '',
          documentName: cleanTitle,
          prompt: `En las conclusiones de ${cleanTitle}, ¿qué aspecto se señala como prioritario para la aplicación práctica?`,
          options: [
            'Integración armónica entre el marco teórico y la ejecución operativa supervisada',
            'Reducción presupuestaria prescindiendo de controles de calidad',
            'Adopción de herramientas no validadas en entornos críticos',
            'Eliminación de la documentación de soporte'
          ],
          correctOptionIndex: 0,
          explanation: 'La efectividad de cualquier disciplina descansa en la coherencia entre teoría documentada y práctica.',
        },
      ];
    }

    // Generate exact count by slicing or dynamically expanding
    const results: Question[] = [];
    for (let i = 0; i < targetCount; i++) {
      if (i < pool.length) {
        results.push({
          ...pool[i],
          id: `q-${Date.now()}-${i + 1}`,
        });
      } else {
        // Procedurally synthesize additional structured questions if count exceeds base pool
        const cycleIdx = (i - pool.length) + 1;
        results.push({
          id: `q-${Date.now()}-${i + 1}`,
          documentId: '',
          documentName: cleanTitle,
          prompt: `En el módulo avanzado (${cycleIdx}) de ${cleanTitle}, ¿qué directriz técnica garantiza la efectividad de las conclusiones?`,
          options: [
            `Verificación cruzada de fuentes y contrastación sistemática según el protocolo ${cycleIdx}`,
            'Supresión de auditorías independientes para reducir tiempos',
            'Emisión de dictámenes basados en percepciones individuales',
            'Uso indistinto de procedimientos no homologados'
          ],
          correctOptionIndex: 0,
          explanation: `El estándar de ${cleanTitle} exige trazabilidad integral y validación cruzada continua.`,
        });
      }
    }

    return results;
  };

  // Progress timer
  useEffect(() => {
    if (step !== 'processing') return;

    const interval = setInterval(() => {
      setProgressPercent((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setDraftQuestions(generateQuestionsForTitle(docTitle, numQuestions));
          setStep('review');
          return 100;
        }
        const next = prev + 8;
        if (next < 20) setCurrentStage(0);
        else if (next < 40) setCurrentStage(1);
        else if (next < 60) setCurrentStage(2);
        else if (next < 80) setCurrentStage(3);
        else if (next < 95) setCurrentStage(4);
        else setCurrentStage(5);
        return next;
      });
    }, 120);

    return () => clearInterval(interval);
  }, [step, docTitle, numQuestions]);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileObj(file);
      setFileName(file.name);
      const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
      setFileSize(`${sizeMb} MB`);
      // Infer title from file name without extension
      const inferredTitle = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      if (!docTitle) {
        setDocTitle(inferredTitle);
      }
    }
  };

  const handleStartProcessing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim()) return;
    if (!fileName) {
      setFileName(`${docTitle.trim()}.pdf`);
      setFileSize('4.2 MB');
    }
    setStep('processing');
    setProgressPercent(0);
    setCurrentStage(0);
  };

  const handleRemoveDraftQuestion = (indexToRemove: number) => {
    setDraftQuestions((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleConfirmAndSave = () => {
    const finalFileName = fileName || `${docTitle}.pdf`;
    const finalFileSize = fileSize || '3.8 MB';
    addDocumentWithQuestions(docTitle, finalFileName, finalFileSize, 64, draftQuestions);
    setStep('upload');
    setProgressPercent(0);
    setDocTitle('');
    setFileName('');
    setFileSize('');
    setFileObj(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-heading">
                Cargar Documento PDF y Generar Preguntas
              </h3>
              <p className="text-[11px] text-slate-500">
                La IA extraerá el contenido y redactará las preguntas automáticamente
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {step === 'upload' && (
            <form onSubmit={handleStartProcessing} className="space-y-4">
              <label className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-2xl p-6 text-center bg-slate-50/60 transition cursor-pointer block">
                <input
                  type="file"
                  accept=".pdf"
                  className="hidden"
                  onChange={handleFileChange}
                />
                <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-slate-200 text-blue-600 flex items-center justify-center mx-auto mb-2">
                  <UploadCloud className="w-6 h-6" />
                </div>
                <div className="text-xs font-bold text-slate-800">
                  {fileName ? 'Archivo seleccionado' : 'Haz clic para seleccionar o arrastra el archivo PDF'}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Formatos admitidos: .pdf (hasta 50 MB)
                </div>
                {fileName ? (
                  <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 bg-white border border-emerald-300 rounded-lg text-xs font-semibold text-emerald-800">
                    <FileText className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{fileName} ({fileSize})</span>
                  </div>
                ) : (
                  <div className="mt-3 text-[11px] text-blue-600 font-medium underline">
                    O introduce el nombre y la IA generará el temario
                  </div>
                )}
              </label>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Título de la Materia o Documento *
                </label>
                <input
                  type="text"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  placeholder="Ej. Derecho Procesal Penal, Criminalística, Inteligencia Artificial..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              {/* Configuración de Cantidad de Preguntas a Generar */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-blue-600" />
                    <span>Cantidad de Preguntas a Generar</span>
                  </label>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-100 text-blue-800 border border-blue-200">
                    {numQuestions} {numQuestions === 1 ? 'pregunta' : 'preguntas'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Selector rápido por botones */}
                  <div className="grid grid-cols-4 gap-1.5 flex-1">
                    {[3, 5, 8, 10].map((qty) => (
                      <button
                        key={qty}
                        type="button"
                        onClick={() => setNumQuestions(qty)}
                        className={`py-2 text-xs font-bold rounded-xl border transition ${
                          numQuestions === qty
                            ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {qty} preg.
                      </button>
                    ))}
                  </div>

                  {/* Stepper numérico personalizado */}
                  <div className="flex items-center bg-white border border-slate-200 rounded-xl p-0.5 shadow-xs shrink-0">
                    <button
                      type="button"
                      onClick={() => setNumQuestions((prev) => Math.max(1, prev - 1))}
                      className="w-7 h-7 rounded-lg text-slate-600 hover:bg-slate-100 flex items-center justify-center font-black text-sm transition"
                      title="Disminuir una pregunta"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={numQuestions}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        if (!isNaN(val)) setNumQuestions(Math.min(20, Math.max(1, val)));
                      }}
                      className="w-10 text-center text-xs font-black text-slate-900 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setNumQuestions((prev) => Math.min(20, prev + 1))}
                      className="w-7 h-7 rounded-lg text-slate-600 hover:bg-slate-100 flex items-center justify-center font-black text-sm transition"
                      title="Aumentar una pregunta"
                    >
                      +
                    </button>
                  </div>
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Configura con cuántas preguntas deseas que la IA elabore el examen. Cada una incluirá 4 opciones y explicación pericial/didáctica.
                </p>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={!docTitle.trim()}
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-md flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Procesar {numQuestions} Preguntas</span>
                </button>
              </div>
            </form>
          )}

          {step === 'processing' && (
            <div className="py-8 text-center space-y-6">
              <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-4 border-blue-100 border-t-blue-600 animate-spin" />
                <div className="text-blue-600">{stages[currentStage].icon}</div>
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900 font-heading">
                  {stages[currentStage].label}
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Extrayendo conceptos y generando reactivos didácticos
                </p>
              </div>

              <div className="space-y-1.5 max-w-xs mx-auto">
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                  <div
                    className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full transition-all duration-200"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <div className="text-[11px] font-bold text-slate-500">{progressPercent}%</div>
              </div>
            </div>
          )}

          {step === 'review' && (
            <div className="space-y-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-blue-900">
                    {draftQuestions.length} preguntas generadas por la IA
                  </h4>
                  <p className="text-[11px] text-blue-700">
                    Revisa las preguntas. Si alguna no te gusta, simplemente elimínala con el botón rojo.
                  </p>
                </div>
              </div>

              {/* Questions list with delete button on each */}
              <div className="space-y-3">
                {draftQuestions.map((q, idx) => (
                  <div
                    key={q.id}
                    className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-2 hover:bg-white transition"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-xs font-bold text-slate-900 leading-snug">
                          {q.prompt}
                        </p>
                      </div>

                      {/* Remove question button */}
                      <button
                        type="button"
                        onClick={() => handleRemoveDraftQuestion(idx)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition shrink-0"
                        title="Quitar esta pregunta"
                      >
                        <Trash2 className="w-4 h-4 text-rose-500" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-1.5 pl-7 text-[11px]">
                      {q.options.map((opt, oIdx) => {
                        const isCorrect = oIdx === q.correctOptionIndex;
                        return (
                          <div
                            key={oIdx}
                            className={`p-1.5 rounded-lg border ${
                              isCorrect
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-semibold'
                                : 'bg-white border-slate-200 text-slate-600'
                            }`}
                          >
                            <span className="font-bold mr-1">{String.fromCharCode(65 + oIdx)}.</span>
                            <span>{opt}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-600">
                  Total para la evaluación: {draftQuestions.length} preguntas
                </span>
                <button
                  type="button"
                  onClick={handleConfirmAndSave}
                  className="px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md flex items-center gap-1.5 transition"
                >
                  <Check className="w-4 h-4" />
                  <span>Guardar en Mis Documentos y Cátedra</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
