import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { AVATARS_GALLERY } from '../../data/mockData';
import { ParticipantAvatar } from '../../types';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Trophy,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Zap,
  Users,
  RotateCcw,
  Crown,
  Home,
  Medal,
  QrCode,
  Clock,
  Lock,
  ChevronRight,
} from 'lucide-react';

export const ParticipantExperience: React.FC = () => {
  const {
    participantSession,
    setParticipantProfile,
    answerQuestion,
    nextQuestion,
    finishParticipant,
    resetParticipant,
    rooms,
    documents,
    login,
  } = useApp();

  // Active room and document
  const activeRoom = rooms.find((r) => r.id === participantSession.roomId) || rooms[0];
  const activeDoc = activeRoom ? documents.find((d) => d.id === activeRoom.documentId) : documents[0];
  const examQuestions = activeDoc?.questions && activeDoc.questions.length > 0
    ? activeDoc.questions
    : [];

  // Sub-screens: 'registro' | 'espera' | 'examen' | 'ranking'
  const [step, setStep] = useState<'registro' | 'espera' | 'examen' | 'ranking'>(() => {
    if (participantSession.isFinished) return 'ranking';
    if (participantSession.name) return 'espera';
    return 'registro';
  });

  // Name & Avatar input - Clean start without fictional names
  const [name, setName] = useState(participantSession.name || '');
  const [selectedAvatar, setSelectedAvatar] = useState<ParticipantAvatar>(
    participantSession.avatar || AVATARS_GALLERY[0]
  );

  // Active question state
  const qIndex = participantSession.currentQuestionIndex;
  const currentQ = examQuestions[qIndex] || examQuestions[0];
  const maxTime = activeRoom?.timePerQuestionSeconds || 20;

  const [timeLeft, setTimeLeft] = useState(maxTime);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [isTimeOver, setIsTimeOver] = useState(false);
  const [gainedPoints, setGainedPoints] = useState<number | null>(null);
  const [revealCountdown, setRevealCountdown] = useState(4);

  // When moving to a new question or entering exam, reset states
  useEffect(() => {
    if (step === 'examen') {
      setTimeLeft(maxTime);
      setSelectedOption(null);
      setHasAnswered(false);
      setIsTimeOver(false);
      setGainedPoints(null);
      setRevealCountdown(4);
    }
  }, [qIndex, step, maxTime]);

  // 1. Countdown timer for answering the question
  // NOTE: Even if the student already answered, the timer continues until 0 to ensure equal fair time!
  useEffect(() => {
    if (step !== 'examen' || isTimeOver) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [step, isTimeOver, qIndex]);

  // 2. Triggered strictly when timeLeft reaches 0 (the answering time has ended)
  useEffect(() => {
    if (step !== 'examen' || timeLeft > 0 || isTimeOver) return;

    // Mark that answering time is officially over
    setIsTimeOver(true);
    setRevealCountdown(4);

    const isAnswerProvided = selectedOption !== null;
    const isCorrect = isAnswerProvided && currentQ && selectedOption === currentQ.correctOptionIndex;
    const timeSpent = maxTime;
    const pts = answerQuestion(Boolean(isCorrect), timeSpent);
    setGainedPoints(pts);

    if (isCorrect) {
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.7 } });
    }
  }, [timeLeft, step, isTimeOver, selectedOption, currentQ, maxTime, answerQuestion]);

  // 3. Exactly 4 seconds of feedback reveal before automatically advancing to next question
  useEffect(() => {
    if (step !== 'examen' || !isTimeOver) return;

    if (revealCountdown <= 0) {
      // Time is up for review! Advance to next question or final ranking
      if (qIndex + 1 >= examQuestions.length) {
        finishParticipant();
        setStep('ranking');
        confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
      } else {
        nextQuestion();
      }
      return;
    }

    const timer = setTimeout(() => {
      setRevealCountdown((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [step, isTimeOver, revealCountdown, qIndex, examQuestions.length, finishParticipant, nextQuestion]);

  // Manual instant advance if user doesn't want to wait the 4 seconds
  const handleAdvanceImmediately = () => {
    if (qIndex + 1 >= examQuestions.length) {
      finishParticipant();
      setStep('ranking');
      confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
    } else {
      nextQuestion();
    }
  };

  // Handle answering: locks the user's selection, but DOES NOT advance or stop the question timer!
  const handleSelectOption = (idx: number) => {
    if (hasAnswered || isTimeOver || !currentQ || timeLeft === 0) return;
    setHasAnswered(true);
    setSelectedOption(idx);
  };

  // Build combined live leaderboard
  const leaderboard = React.useMemo(() => {
    const userItem = {
      id: 'current-user',
      name: name || 'Tú',
      avatarEmoji: selectedAvatar.emoji,
      avatarBg: selectedAvatar.bgColor,
      score: participantSession.score,
      correctAnswers: participantSession.correctCount,
      totalTimeSeconds: (activeRoom?.timePerQuestionSeconds || 20) * (participantSession.answersCount || 1),
      isCurrentUser: true,
    };

    const others = (activeRoom?.participants || []).map((p) => ({
      ...p,
      isCurrentUser: false,
    }));

    const combined = [userItem, ...others];
    combined.sort((a, b) => b.score - a.score);
    return combined;
  }, [activeRoom?.participants, activeRoom?.timePerQuestionSeconds, name, selectedAvatar, participantSession.score, participantSession.correctCount, participantSession.answersCount]);

  const optionColors = [
    'bg-rose-600 hover:bg-rose-500',
    'bg-blue-600 hover:bg-blue-500',
    'bg-amber-500 hover:bg-amber-400',
    'bg-emerald-600 hover:bg-emerald-500',
  ];

  if (!activeRoom || !activeDoc || examQuestions.length === 0) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
        <header className="h-14 px-4 border-b border-slate-800 bg-slate-900/60 backdrop-blur-md flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white text-xs">
              AI
            </div>
            <span className="font-heading font-extrabold text-sm text-white">
              Evalua<span className="text-blue-400">IA</span>
            </span>
          </div>
          <button
            onClick={() => login('docente')}
            className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 transition"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Panel Docente</span>
          </button>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center p-4 max-w-md mx-auto w-full text-center">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 space-y-4 shadow-2xl w-full">
            <div className="w-14 h-14 rounded-2xl bg-slate-800/80 text-blue-400 flex items-center justify-center mx-auto">
              <QrCode className="w-7 h-7" />
            </div>
            <h2 className="text-base font-bold text-white font-heading">
              No hay ninguna sala de evaluación activa
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              El sistema está en estado inicial. El docente debe cargar un documento PDF y generar el código QR de la sala para comenzar la actividad.
            </p>
            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => login('docente')}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
              >
                Ingresar como Docente (Cargar PDF)
              </button>
              <button
                onClick={() => login('admin')}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition"
              >
                Ingresar como Administrador
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Bar */}
      <header className="h-14 px-4 border-b border-slate-800 bg-slate-900/60 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white text-xs">
            AI
          </div>
          <div>
            <span className="font-heading font-extrabold text-sm text-white">
              Evalua<span className="text-blue-400">IA</span>
            </span>
            <span className="text-[10px] text-slate-400 font-mono ml-2">
              Sala: {activeRoom?.roomCode || '---'}
            </span>
          </div>
        </div>

        <button
          onClick={() => login('docente')}
          className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 transition"
        >
          <Home className="w-3.5 h-3.5" />
          <span>Salir</span>
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 max-w-2xl mx-auto w-full">
        {/* ============================================================ */}
        {/* 1. REGISTRO: NOMBRE + AVATAR */}
        {/* ============================================================ */}
        {step === 'registro' && (
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl text-center animate-in zoom-in-95">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-blue-400">
                Bienvenido al Examen
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white font-heading mt-0.5">
                {activeDoc.title}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Escribe tu nombre y elige tu avatar para comenzar
              </p>
            </div>

            {/* Name */}
            <div className="text-left">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Tu Nombre
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ej. Ingresa tu nombre completo"
                className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-2xl text-white text-sm font-semibold focus:outline-none focus:border-blue-500"
                required
              />
            </div>

            {/* Avatars Gallery */}
            <div className="text-left">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Selecciona tu Avatar ({selectedAvatar.name}):
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-h-48 overflow-y-auto p-2 bg-slate-950 rounded-2xl border border-slate-800">
                {AVATARS_GALLERY.map((av) => {
                  const isSelected = selectedAvatar.id === av.id;
                  return (
                    <button
                      key={av.id}
                      type="button"
                      onClick={() => setSelectedAvatar(av)}
                      className={`p-2 rounded-xl flex flex-col items-center justify-center gap-1 transition ${
                        isSelected
                          ? `${av.bgColor} ring-2 ring-white scale-105`
                          : 'bg-slate-900 hover:bg-slate-800'
                      }`}
                    >
                      <span className="text-2xl">{av.emoji}</span>
                      <span className="text-[9px] font-bold text-white truncate max-w-full">
                        {av.name.split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              onClick={() => {
                if (!name.trim()) return;
                setParticipantProfile(name, selectedAvatar);
                setStep('espera');
              }}
              className="w-full py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition"
            >
              <span>Entrar a la Sala</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ============================================================ */}
        {/* 2. SALA DE ESPERA */}
        {/* ============================================================ */}
        {step === 'espera' && (
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 text-center space-y-6 shadow-2xl animate-in fade-in">
            <div
              className={`w-20 h-20 rounded-3xl ${selectedAvatar.bgColor} text-white flex items-center justify-center text-4xl shadow-xl mx-auto ring-4 ring-slate-800`}
            >
              {selectedAvatar.emoji}
            </div>

            <div>
              <h3 className="text-xl font-black text-white font-heading">
                {name}
              </h3>
              <p className="text-xs text-blue-400 font-semibold mt-0.5">
                {selectedAvatar.name}
              </p>
              <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-xs font-mono border border-slate-700">
                <span>Sala: {activeRoom?.roomCode || '---'}</span>
                <span>•</span>
                <span className="text-emerald-400 font-sans flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" />
                  {activeRoom?.participants?.length || 0} conectados
                </span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-purple-500 animate-bounce [animation-delay:0.4s]" />
              </div>
              <p className="text-xs font-bold text-slate-300">
                Esperando a que el docente inicie la actividad...
              </p>
            </div>

            <button
              onClick={() => setStep('examen')}
              className="w-full py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition"
            >
              <Zap className="w-4 h-4 fill-white" />
              <span>Comenzar Actividad Ahora</span>
            </button>
          </div>
        )}

        {/* ============================================================ */}
        {/* 3. EXAMEN EN VIVO */}
        {/* ============================================================ */}
        {step === 'examen' && currentQ && (
          <div className="w-full space-y-4 animate-in fade-in">
            {/* Top Bar: Progress, Timer, Score */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-blue-600 text-white font-black text-xs">
                  {qIndex + 1} de {examQuestions.length}
                </span>
              </div>

              {/* Countdown Timer */}
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shadow transition ${
                  timeLeft <= 5 ? 'bg-rose-600 text-white animate-ping' : 'bg-slate-800 text-blue-400'
                }`}
              >
                {timeLeft}s
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Puntos</span>
                <span className="text-xs font-mono font-black text-amber-400">
                  {participantSession.score} pts
                </span>
              </div>
            </div>

            {/* Prompt */}
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 text-center min-h-[120px] flex items-center justify-center">
              <h2 className="text-base sm:text-xl font-extrabold text-white font-heading leading-snug">
                {currentQ.prompt}
              </h2>
            </div>

            {/* 4 Colored Option Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentQ.options.map((opt, idx) => {
                const color = optionColors[idx % 4];
                const isSelected = selectedOption === idx;
                const isCorrect = idx === currentQ.correctOptionIndex;

                let cardState = color;
                if (isTimeOver) {
                  // Time has expired: Reveal correct vs wrong
                  if (isCorrect) cardState = 'bg-emerald-600 ring-4 ring-emerald-300';
                  else if (isSelected && !isCorrect) cardState = 'bg-rose-700 ring-4 ring-rose-400';
                  else cardState = 'bg-slate-900/50 opacity-40 border border-slate-800';
                } else if (hasAnswered) {
                  // Student answered, but time is still running: Highlight their choice and lock
                  if (isSelected) cardState = `${color} ring-4 ring-white shadow-2xl scale-[1.01]`;
                  else cardState = 'bg-slate-900/60 opacity-50 border border-slate-800 cursor-not-allowed';
                }

                return (
                  <button
                    key={idx}
                    type="button"
                    disabled={hasAnswered || isTimeOver}
                    onClick={() => handleSelectOption(idx)}
                    className={`p-4 rounded-2xl text-left text-white shadow-lg transition flex items-center gap-3 ${cardState} ${
                      !hasAnswered && !isTimeOver ? 'hover:scale-[1.01] active:scale-[0.99] cursor-pointer' : 'cursor-default'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-xl bg-black/20 flex items-center justify-center font-black text-sm shrink-0">
                      {String.fromCharCode(65 + idx)}
                    </div>
                    <span className="text-xs sm:text-sm font-bold flex-1 leading-snug">
                      {opt}
                    </span>
                    {hasAnswered && !isTimeOver && isSelected && (
                      <span className="text-[10px] bg-black/40 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shrink-0">
                        <Lock className="w-2.5 h-2.5" />
                        <span>Elegida</span>
                      </span>
                    )}
                    {isTimeOver && isCorrect && <CheckCircle2 className="w-5 h-5 text-white shrink-0" />}
                    {isTimeOver && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-white shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Waiting state: Student answered, but waiting for question timer to end */}
            {hasAnswered && !isTimeOver && (
              <div className="p-3.5 rounded-2xl bg-blue-950/80 border border-blue-500/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs animate-in fade-in">
                <div className="flex items-center gap-2 text-blue-200 font-bold">
                  <Lock className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>Tu respuesta fue registrada. Esperando que termine el tiempo de la pregunta...</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-blue-900/90 text-white font-mono font-black text-xs shrink-0 self-end sm:self-auto">
                  <Clock className="w-3.5 h-3.5 text-blue-400" />
                  <span>{timeLeft}s restantes</span>
                </div>
              </div>
            )}

            {/* Time Over Reveal: Triggered strictly when question time reaches 0 */}
            {isTimeOver && (
              <div
                className={`p-4 rounded-3xl border text-xs font-bold space-y-3 animate-in zoom-in-95 shadow-xl ${
                  selectedOption === currentQ.correctOptionIndex
                    ? 'bg-emerald-950/90 text-emerald-100 border-emerald-500/80 shadow-emerald-950/50'
                    : 'bg-rose-950/90 text-rose-100 border-rose-500/80 shadow-rose-950/50'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-white/10">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-2xl flex items-center justify-center font-bold text-white shadow-md shrink-0 ${
                        selectedOption === currentQ.correctOptionIndex ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                    >
                      {selectedOption === currentQ.correctOptionIndex ? (
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      ) : (
                        <XCircle className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <div>
                      <div className="text-sm sm:text-base font-black tracking-tight">
                        {selectedOption === currentQ.correctOptionIndex
                          ? `¡Respuesta Correcta! (+${gainedPoints} pts)`
                          : selectedOption !== null
                          ? 'Respuesta Incorrecta'
                          : '¡Tiempo Agotado sin Responder!'}
                      </div>
                      <div className="text-[11px] opacity-80 mt-0.5">
                        {selectedOption === currentQ.correctOptionIndex
                          ? 'Excelente precisión y velocidad de respuesta'
                          : `La correcta era la opción ${String.fromCharCode(65 + currentQ.correctOptionIndex)}: ${currentQ.options[currentQ.correctOptionIndex]}`}
                      </div>
                    </div>
                  </div>

                  {/* 4s Countdown Badge & Instant Advance */}
                  <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    <div className="px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-white font-mono font-bold text-xs flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                      <span>{revealCountdown}s</span>
                    </div>

                    <button
                      type="button"
                      onClick={handleAdvanceImmediately}
                      className="px-3.5 py-1.5 rounded-xl bg-white text-slate-900 hover:bg-slate-100 font-extrabold text-xs shadow-md transition flex items-center gap-1"
                    >
                      <span>Avanzar ya</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Animated 4-second progress indicator bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] opacity-75 font-mono">
                    <span>
                      {qIndex + 1 >= examQuestions.length
                        ? 'Finalizando evaluación y generando podio...'
                        : `Cargando pregunta ${qIndex + 2} de ${examQuestions.length}...`}
                    </span>
                    <span>{revealCountdown} segundos restantes</span>
                  </div>
                  <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-white transition-all duration-1000 ease-linear rounded-full"
                      style={{ width: `${Math.max(5, (revealCountdown / 4) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* 4. RANKING AUTOMÁTICO AL TERMINAR */}
        {/* ============================================================ */}
        {step === 'ranking' && (
          <div className="w-full space-y-6 animate-in fade-in">
            {/* Header */}
            <div className="text-center space-y-1">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400 flex items-center justify-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>Actividad Finalizada</span>
              </span>
              <h2 className="text-2xl font-black text-white font-heading">
                Ranking y Clasificación
              </h2>
              <p className="text-xs text-slate-400">
                Puntuación acumulada: <strong className="text-amber-400">{participantSession.score} pts</strong>
              </p>
            </div>

            {/* Top 3 Podium */}
            <div className="flex items-end justify-center gap-2 max-w-sm mx-auto pt-4">
              {/* 2nd Silver */}
              {leaderboard[1] && (
                <div className="flex-1 flex flex-col items-center">
                  <div
                    className={`w-12 h-12 rounded-2xl ${leaderboard[1].avatarBg} text-white flex items-center justify-center text-xl shadow`}
                  >
                    {leaderboard[1].avatarEmoji}
                  </div>
                  <div className="text-[11px] font-bold text-white mt-1 truncate max-w-[80px]">
                    {leaderboard[1].name}
                  </div>
                  <div className="text-[10px] font-mono text-slate-300">
                    {leaderboard[1].score} pts
                  </div>
                  <div className="w-full h-20 rounded-t-xl bg-slate-800 border-t border-slate-500 flex items-center justify-center font-bold text-lg text-slate-300 mt-2">
                    2°
                  </div>
                </div>
              )}

              {/* 1st Gold */}
              {leaderboard[0] && (
                <div className="flex-1 flex flex-col items-center z-10">
                  <Crown className="w-5 h-5 text-amber-400 mb-1" />
                  <div
                    className={`w-14 h-14 rounded-2xl ${leaderboard[0].avatarBg} text-white flex items-center justify-center text-2xl shadow-xl ring-2 ring-amber-400`}
                  >
                    {leaderboard[0].avatarEmoji}
                  </div>
                  <div className="text-xs font-black text-amber-300 mt-1 truncate max-w-[90px]">
                    {leaderboard[0].name}
                  </div>
                  <div className="text-xs font-mono font-black text-amber-400">
                    {leaderboard[0].score} pts
                  </div>
                  <div className="w-full h-28 rounded-t-xl bg-amber-500 border-t-2 border-yellow-200 flex items-center justify-center font-black text-2xl text-slate-950 mt-2">
                    1°
                  </div>
                </div>
              )}

              {/* 3rd Bronze */}
              {leaderboard[2] && (
                <div className="flex-1 flex flex-col items-center">
                  <div
                    className={`w-12 h-12 rounded-2xl ${leaderboard[2].avatarBg} text-white flex items-center justify-center text-xl shadow`}
                  >
                    {leaderboard[2].avatarEmoji}
                  </div>
                  <div className="text-[11px] font-bold text-white mt-1 truncate max-w-[80px]">
                    {leaderboard[2].name}
                  </div>
                  <div className="text-[10px] font-mono text-amber-500">
                    {leaderboard[2].score} pts
                  </div>
                  <div className="w-full h-16 rounded-t-xl bg-slate-900 border-t border-amber-700 flex items-center justify-center font-bold text-lg text-amber-700 mt-2">
                    3°
                  </div>
                </div>
              )}
            </div>

            {/* Complete Ranking List */}
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
              <span className="text-[11px] font-bold text-slate-400 block pb-1 border-b border-slate-800">
                Todos los Participantes
              </span>

              <div className="divide-y divide-slate-800 max-h-56 overflow-y-auto">
                {leaderboard.map((item, idx) => (
                  <div
                    key={item.id}
                    className={`py-2 px-2 flex items-center justify-between ${
                      item.isCurrentUser ? 'bg-blue-600/20 text-white font-bold rounded-lg' : 'text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-5 font-bold text-slate-400 text-xs">{idx + 1}°</span>
                      <span className={`w-6 h-6 rounded-md ${item.avatarBg} text-white flex items-center justify-center text-xs`}>
                        {item.avatarEmoji}
                      </span>
                      <span>{item.name} {item.isCurrentUser && '(Tú)'}</span>
                    </div>
                    <span className="font-mono font-bold text-amber-400">{item.score} pts</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  resetParticipant();
                  setStep('registro');
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Volver a Intentar</span>
              </button>

              <button
                onClick={() => login('docente')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
              >
                <Home className="w-4 h-4" />
                <span>Ir al Panel Docente</span>
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
