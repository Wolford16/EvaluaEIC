export type UserRole = 'admin' | 'docente' | 'participante';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'docente';
  avatar: string;
  title?: string;
  status: 'active' | 'inactive';
}

export interface Question {
  id: string;
  documentId: string;
  documentName: string;
  prompt: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface StudyDocument {
  id: string;
  title: string;
  fileName: string;
  uploadedBy: string;
  uploadedById: string;
  uploadDate: string;
  fileSize: string;
  pages: number;
  topics?: string[];
  questions: Question[];
  summary?: string;
}

export interface ParticipantAvatar {
  id: string;
  name: string;
  emoji: string;
  bgColor: string;
  textColor: string;
}

export interface LiveParticipant {
  id: string;
  name: string;
  avatarId: string;
  avatarEmoji: string;
  avatarBg: string;
  score: number;
  correctAnswers: number;
  wrongAnswers: number;
  totalTimeSeconds: number;
  joinedAt: string;
  percentage?: number;
  isCurrentUser?: boolean;
}

export interface EvaluationRoom {
  id: string;
  documentId: string;
  documentTitle: string;
  roomCode: string;
  createdDate: string;
  timePerQuestionSeconds: number;
  status: 'esperando' | 'en_curso' | 'finalizada';
  participants: LiveParticipant[];
}

export interface AiProviderConfig {
  id: 'gemini' | 'openrouter' | 'ollama';
  name: string;
  model: string;
  status: 'disponible' | 'activo' | 'no_conectado';
  apiUrl: string;
  latencyMs: number;
  description: string;
}
