import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { ToastContainer } from './components/common/ToastContainer';
import { LoginView } from './components/auth/LoginView';
import { DocenteMaterialView } from './components/docente/DocenteMaterialView';
import { AdminSimpleView } from './components/admin/AdminSimpleView';
import { UploadDocumentModal } from './components/documents/UploadDocumentModal';
import { ParticipantExperience } from './components/participant/ParticipantExperience';

const MainAppContent: React.FC = () => {
  const { currentRole, activeTab } = useApp();
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // 1. If unauthenticated, show Login
  if (currentRole === 'guest') {
    return <LoginView />;
  }

  // 2. If student participant, show dedicated gamified flow
  if (currentRole === 'participante' || activeTab === 'participante') {
    return (
      <>
        <ParticipantExperience />
        <ToastContainer />
      </>
    );
  }

  // 3. Authenticated view: Docente/Supervisor or Admin
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      <Navbar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto">
        {currentRole === 'admin' ? (
          <AdminSimpleView />
        ) : (
          <DocenteMaterialView onOpenUpload={() => setIsUploadModalOpen(true)} />
        )}
      </main>

      {/* Upload Document Modal with AI Question Review */}
      <UploadDocumentModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
      />

      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
