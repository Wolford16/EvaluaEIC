import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  StudyDocument,
  Question,
  EvaluationRoom,
  LiveParticipant,
  ParticipantAvatar,
  AiProviderConfig,
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_DOCUMENTS,
  INITIAL_ROOMS,
  INITIAL_AI_PROVIDERS,
  AVATARS_GALLERY,
} from '../data/mockData';

interface ToastMsg {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  text: string;
}

interface AppContextType {
  currentUser: User | null;
  currentRole: UserRole | 'guest';
  activeTab: string;
  setActiveTab: (tab: string) => void;
  login: (role: 'admin' | 'docente') => void;
  logout: () => void;
  switchRole: (role: UserRole) => void;

  // Documents & material de cátedra
  documents: StudyDocument[];
  addDocumentWithQuestions: (title: string, fileName: string, fileSize: string, pages: number, questions: Question[]) => StudyDocument;
  removeQuestionFromDocument: (docId: string, questionId: string) => void;
  deleteDocument: (docId: string) => void;
  selectedDocId: string | null;
  setSelectedDocId: (id: string | null) => void;

  // Rooms & QR
  rooms: EvaluationRoom[];
  activeRoomId: string | null;
  setActiveRoomId: (id: string | null) => void;
  createRoomForDocument: (docId: string, timeSeconds?: number) => EvaluationRoom;
  startRoomActivity: (roomId: string) => void;
  finishRoomActivity: (roomId: string) => void;

  // Users (Admin feature)
  users: User[];
  createUser: (name: string, email: string, role: 'docente' | 'admin') => void;
  toggleUserStatus: (id: string) => void;

  // AI Providers (Admin feature)
  aiProviders: AiProviderConfig[];
  setActiveAiProvider: (id: 'gemini' | 'openrouter' | 'ollama') => void;

  // Participant Session (No login required)
  participantSession: {
    name: string;
    avatar: ParticipantAvatar;
    roomId: string;
    score: number;
    currentQuestionIndex: number;
    answersCount: number;
    correctCount: number;
    isFinished: boolean;
  };
  startParticipantFlow: (roomId?: string) => void;
  setParticipantProfile: (name: string, avatar: ParticipantAvatar) => void;
  answerQuestion: (isCorrect: boolean, timeSpent: number) => number;
  nextQuestion: () => void;
  finishParticipant: () => void;
  resetParticipant: () => void;

  // Toasts & Reset
  toasts: ToastMsg[];
  showToast: (type: ToastMsg['type'], text: string) => void;
  dismissToast: (id: string) => void;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  ROLE: 'evalua_sim_role_v5',
  DOCUMENTS: 'evalua_sim_docs_v5',
  ROOMS: 'evalua_sim_rooms_v5',
  USERS: 'evalua_sim_users_v5',
  AI: 'evalua_sim_ai_v5',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRole, setCurrentRole] = useState<UserRole | 'guest'>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE);
    if (saved === 'admin' || saved === 'docente' || saved === 'participante') return saved;
    return 'docente'; // default directly to docente/supervisor
  });

  const [activeTab, setActiveTab] = useState<string>('documentos');

  // Documents: Purge any dactiloscopia and default to the clean document
  const [documents, setDocuments] = useState<StudyDocument[]>(() => {
    try {
      const s = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
      const list: StudyDocument[] = s ? JSON.parse(s) : INITIAL_DOCUMENTS;
      const filtered = list.filter(
        (d) => !d.title.toLowerCase().includes('dactilo') && !d.fileName.toLowerCase().includes('dactilo')
      );
      return filtered.length > 0 ? filtered : INITIAL_DOCUMENTS;
    } catch {
      return INITIAL_DOCUMENTS;
    }
  });

  // Selected doc ID: starts as NULL so only PDF identification cards are shown by default!
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);

  // Rooms: Purge any dactiloscopia rooms
  const [rooms, setRooms] = useState<EvaluationRoom[]>(() => {
    try {
      const s = localStorage.getItem(STORAGE_KEYS.ROOMS);
      const list: EvaluationRoom[] = s ? JSON.parse(s) : INITIAL_ROOMS;
      const filtered = list.filter((r) => !r.documentTitle.toLowerCase().includes('dactilo'));
      return filtered.length > 0 ? filtered : INITIAL_ROOMS;
    } catch {
      return INITIAL_ROOMS;
    }
  });

  const [activeRoomId, setActiveRoomId] = useState<string | null>(() => {
    return rooms[0]?.id || null;
  });

  // Users (for admin)
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const s = localStorage.getItem(STORAGE_KEYS.USERS);
      return s ? JSON.parse(s) : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  });

  // AI Providers
  const [aiProviders, setAiProviders] = useState<AiProviderConfig[]>(() => {
    try {
      const s = localStorage.getItem(STORAGE_KEYS.AI);
      return s ? JSON.parse(s) : INITIAL_AI_PROVIDERS;
    } catch {
      return INITIAL_AI_PROVIDERS;
    }
  });

  // Toasts
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  const showToast = (type: ToastMsg['type'], text: string) => {
    const id = String(Date.now());
    setToasts((prev) => [...prev, { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };
  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Participant Session
  const [participantSession, setParticipantSession] = useState<{
    name: string;
    avatar: ParticipantAvatar;
    roomId: string;
    score: number;
    currentQuestionIndex: number;
    answersCount: number;
    correctCount: number;
    isFinished: boolean;
  }>({
    name: '',
    avatar: AVATARS_GALLERY[0],
    roomId: '',
    score: 0,
    currentQuestionIndex: 0,
    answersCount: 0,
    correctCount: 0,
    isFinished: false,
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify(rooms));
  }, [rooms]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AI, JSON.stringify(aiProviders));
  }, [aiProviders]);

  const currentUser = users.find((u) => u.role === currentRole) || users[1];

  const login = (role: 'admin' | 'docente') => {
    setCurrentRole(role);
    localStorage.setItem(STORAGE_KEYS.ROLE, role);
    if (role === 'admin') {
      setActiveTab('documentos');
    } else {
      setActiveTab('documentos');
    }
    showToast('success', `Sesión iniciada como ${role === 'admin' ? 'Administrador' : 'Docente / Supervisor'}`);
  };

  const logout = () => {
    setCurrentRole('guest');
    localStorage.removeItem(STORAGE_KEYS.ROLE);
    showToast('info', 'Sesión cerrada');
  };

  const switchRole = (role: UserRole) => {
    setCurrentRole(role);
    localStorage.setItem(STORAGE_KEYS.ROLE, role);
    if (role === 'participante') {
      setActiveTab('participante');
    } else {
      setActiveTab('documentos');
    }
  };

  // Document actions
  const addDocumentWithQuestions = (
    title: string,
    fileName: string,
    fileSize: string,
    pages: number,
    generatedQuestions: Question[]
  ) => {
    const newDocId = 'doc-' + (documents.length + 1);
    const questionsWithDocId = generatedQuestions.map((q, idx) => ({
      ...q,
      id: `q-${newDocId}-${idx + 1}`,
      documentId: newDocId,
      documentName: title,
    }));

    const newDoc: StudyDocument = {
      id: newDocId,
      title,
      fileName,
      uploadedBy: currentUser?.name || 'Prof. Roberto Valenzuela',
      uploadedById: currentUser?.id || 'u-doc',
      uploadDate: new Date().toISOString().split('T')[0],
      fileSize,
      pages,
      questions: questionsWithDocId,
      summary: `Documento procesado con IA. Contiene ${questionsWithDocId.length} preguntas listas para evaluación.`,
    };

    setDocuments((prev) => [newDoc, ...prev]);
    setSelectedDocId(newDoc.id);
    showToast('success', `Documento guardado con ${questionsWithDocId.length} preguntas`);
    return newDoc;
  };

  const removeQuestionFromDocument = (docId: string, questionId: string) => {
    setDocuments((prev) =>
      prev.map((d) => {
        if (d.id === docId) {
          return {
            ...d,
            questions: d.questions.filter((q) => q.id !== questionId),
          };
        }
        return d;
      })
    );
    showToast('info', 'Pregunta eliminada de este documento');
  };

  const deleteDocument = (docId: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
    if (selectedDocId === docId) {
      setSelectedDocId(documents[0]?.id || null);
    }
    showToast('info', 'Documento eliminado');
  };

  // Rooms & QR
  const createRoomForDocument = (docId: string, timeSeconds = 20): EvaluationRoom => {
    const doc = documents.find((d) => d.id === docId);
    const docTitle = doc?.title || 'Evaluación';
    const roomCode = 'QR-' + Math.floor(1000 + Math.random() * 9000);
    const newRoom: EvaluationRoom = {
      id: 'room-' + Date.now(),
      documentId: docId,
      documentTitle: docTitle,
      roomCode,
      createdDate: new Date().toISOString().split('T')[0],
      timePerQuestionSeconds: timeSeconds,
      status: 'esperando',
      participants: [],
    };
    setRooms((prev) => [newRoom, ...prev]);
    setActiveRoomId(newRoom.id);
    showToast('success', `Sala QR ${roomCode} generada para ${docTitle}`);
    return newRoom;
  };

  const startRoomActivity = (roomId: string) => {
    setRooms((prev) =>
      prev.map((r) => (r.id === roomId ? { ...r, status: 'en_curso' } : r))
    );
    showToast('success', '¡Actividad iniciada! Los participantes ya pueden responder');
  };

  const finishRoomActivity = (roomId: string) => {
    setRooms((prev) =>
      prev.map((r) => (r.id === roomId ? { ...r, status: 'finalizada' } : r))
    );
    showToast('info', 'Actividad finalizada. Mostrando ranking');
  };

  // Users (Admin feature)
  const createUser = (name: string, email: string, role: 'docente' | 'admin') => {
    const newUser: User = {
      id: 'u-' + Date.now(),
      name,
      email,
      role,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      title: role === 'admin' ? 'Administrador' : 'Docente / Supervisor',
      status: 'active',
    };
    setUsers((prev) => [newUser, ...prev]);
    showToast('success', `Usuario ${name} creado con éxito`);
  };

  const toggleUserStatus = (id: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === id ? { ...u, status: u.status === 'active' ? 'inactive' : 'active' } : u))
    );
    showToast('info', 'Estado de usuario actualizado');
  };

  // AI Providers
  const setActiveAiProvider = (id: 'gemini' | 'openrouter' | 'ollama') => {
    setAiProviders((prev) =>
      prev.map((p) => ({
        ...p,
        status: p.id === id ? 'activo' : 'disponible',
      }))
    );
    showToast('success', `Motor activo cambiado a ${id.toUpperCase()}`);
  };

  // Participant flow
  const startParticipantFlow = (roomId?: string) => {
    const targetRoom = rooms.find((r) => r.id === roomId) || rooms[0];
    setParticipantSession({
      name: '',
      avatar: AVATARS_GALLERY[0],
      roomId: targetRoom?.id || '',
      score: 0,
      currentQuestionIndex: 0,
      answersCount: 0,
      correctCount: 0,
      isFinished: false,
    });
    setCurrentRole('participante');
    setActiveTab('participante');
  };

  const setParticipantProfile = (name: string, avatar: ParticipantAvatar) => {
    setParticipantSession((prev) => ({
      ...prev,
      name,
      avatar,
    }));
    showToast('success', `¡Bienvenido, ${name}!`);
  };

  const answerQuestion = (isCorrect: boolean, timeSpent: number): number => {
    const maxTime = 20;
    const remaining = Math.max(0, maxTime - timeSpent);
    const speedBonus = isCorrect ? Math.round((remaining / maxTime) * 500) : 0;
    const earned = isCorrect ? 1000 + speedBonus : 0;

    setParticipantSession((prev) => ({
      ...prev,
      score: prev.score + earned,
      answersCount: prev.answersCount + 1,
      correctCount: prev.correctCount + (isCorrect ? 1 : 0),
    }));

    return earned;
  };

  const nextQuestion = () => {
    setParticipantSession((prev) => ({
      ...prev,
      currentQuestionIndex: prev.currentQuestionIndex + 1,
    }));
  };

  const finishParticipant = () => {
    setParticipantSession((prev) => ({
      ...prev,
      isFinished: true,
    }));
  };

  const resetParticipant = () => {
    setParticipantSession({
      name: '',
      avatar: AVATARS_GALLERY[0],
      roomId: rooms[0]?.id || 'room-1',
      score: 0,
      currentQuestionIndex: 0,
      answersCount: 0,
      correctCount: 0,
      isFinished: false,
    });
  };

  const resetAllData = () => {
    localStorage.removeItem(STORAGE_KEYS.DOCUMENTS);
    localStorage.removeItem(STORAGE_KEYS.ROOMS);
    localStorage.removeItem(STORAGE_KEYS.USERS);
    localStorage.removeItem(STORAGE_KEYS.AI);
    setDocuments(INITIAL_DOCUMENTS);
    setRooms(INITIAL_ROOMS);
    setUsers(INITIAL_USERS);
    setAiProviders(INITIAL_AI_PROVIDERS);
    setSelectedDocId(null);
    setActiveRoomId(INITIAL_ROOMS[0]?.id || null);
    showToast('info', 'Sistema restablecido con material de prueba');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        currentRole,
        activeTab,
        setActiveTab,
        login,
        logout,
        switchRole,

        documents,
        addDocumentWithQuestions,
        removeQuestionFromDocument,
        deleteDocument,
        selectedDocId,
        setSelectedDocId,

        rooms,
        activeRoomId,
        setActiveRoomId,
        createRoomForDocument,
        startRoomActivity,
        finishRoomActivity,

        users,
        createUser,
        toggleUserStatus,

        aiProviders,
        setActiveAiProvider,

        participantSession,
        startParticipantFlow,
        setParticipantProfile,
        answerQuestion,
        nextQuestion,
        finishParticipant,
        resetParticipant,

        toasts,
        showToast,
        dismissToast,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
